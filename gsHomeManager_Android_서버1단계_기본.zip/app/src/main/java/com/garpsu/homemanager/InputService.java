package com.garpsu.homemanager;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;

import java.util.ArrayDeque;

/**
 * PC 에서 온 마우스 / 키 입력을 폰에 넣는 접근성 서비스 (서버 모드).
 * 사용자가 설정 > 접근성에서 켜야 동작한다. 꺼져 있으면 화면 보기만 되고 조작은 무시한다.
 * 왼쪽 클릭 = 터치, 왼쪽 누른 채 끌기 = 스와이프(손을 뗄 때 같은 경로를 같은 시간으로 재생), 오른쪽 클릭 = 뒤로, 가운데 클릭 = 홈, 휠 = 스크롤.
 */
public class InputService extends AccessibilityService {
    private static final int EV_MOVE = 1, EV_BTN = 2, EV_WHEEL = 3, EV_KEY = 4;
    private static final int BTN_LDOWN = 0x0002, BTN_LUP = 0x0004, BTN_RUP = 0x0010, BTN_MUP = 0x0040;
    private static final int VK_ESCAPE = 0x1B, VK_PRIOR = 0x21, VK_NEXT = 0x22, VK_END = 0x23, VK_HOME = 0x24;
    private static final int MAX_QUEUE = 10;

    static volatile InputService inst;                      // 서비스가 켜져 있으면 non-null
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ArrayDeque<GestureDescription> queue = new ArrayDeque<>();   // 메인 스레드에서만 사용
    private boolean dispatching;

    // 마우스 상태 (handle / reset 에서 synchronized)
    private static float cx = 0.5f, cy = 0.5f;              // 커서 위치 (0.0 ~ 1.0)
    private static boolean down, moved;
    private static float sx, sy, lx, ly;
    private static Path path;
    private static long downT;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        if (inst == this) inst = null;
        return super.onUnbind(intent);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    /** 서버 연결이 끊기면 눌려 있던 상태를 버림 */
    static synchronized void reset() { down = false; moved = false; path = null; }

    /** PC 에서 온 입력 이벤트 하나 처리 (ScreenServer 읽기 스레드) */
    static synchronized void handle(int t, int a, int b, int m) {
        final InputService s = inst;
        if (s == null) return;
        final int[] sz = s.screen();
        final float W = sz[0], H = sz[1];
        final float slop = 10f * sz[2] / 160f;
        switch (t) {
            case EV_MOVE: {
                cx = a / 65535f;
                cy = b / 65535f;
                if (down) {
                    final float x = cx * W, y = cy * H;
                    if (!moved && Math.hypot(x - sx, y - sy) > slop) moved = true;
                    if (moved && Math.hypot(x - lx, y - ly) >= 4f) { path.lineTo(clamp(x, W), clamp(y, H)); lx = x; ly = y; }
                }
                break;
            }
            case EV_BTN: {
                if (a == BTN_LDOWN) {
                    down = true;
                    moved = false;
                    sx = lx = clamp(cx * W, W);
                    sy = ly = clamp(cy * H, H);
                    path = new Path();
                    path.moveTo(sx, sy);
                    downT = SystemClock.uptimeMillis();
                } else if (a == BTN_LUP && down) {
                    down = false;
                    final long dur = SystemClock.uptimeMillis() - downT;
                    if (!moved) {
                        s.gesture(path, dur >= 450 ? 700 : 50);                       // 짧게 = 탭, 오래 = 길게 누르기
                    } else {
                        path.lineTo(clamp(cx * W, W), clamp(cy * H, H));
                        s.gesture(path, Math.max(100, Math.min(dur, 4000)));
                    }
                    path = null;
                } else if (a == BTN_RUP) {
                    s.global(GLOBAL_ACTION_BACK);
                } else if (a == BTN_MUP) {
                    s.global(GLOBAL_ACTION_HOME);
                }
                break;
            }
            case EV_WHEEL:
                s.scroll(cx * W, cy * H, W, H, a > 0);      // 휠 위로(양수) = 내용이 아래로 = 손가락을 아래로 끌기
                break;
            case EV_KEY: {
                if ((b & 1) != 0) break;                    // 키를 뗄 때는 무시
                switch (a) {
                    case VK_ESCAPE: s.global(GLOBAL_ACTION_BACK); break;
                    case VK_HOME: s.global(GLOBAL_ACTION_HOME); break;
                    case VK_END: s.global(GLOBAL_ACTION_RECENTS); break;
                    case VK_PRIOR: s.scroll(W / 2, H / 2, W, H, true); break;
                    case VK_NEXT: s.scroll(W / 2, H / 2, W, H, false); break;
                    default: break;                         // 글자 입력은 지원하지 않음
                }
                break;
            }
            default: break;
        }
    }

    private static float clamp(float v, float max) { return Math.max(0f, Math.min(max - 1f, v)); }

    /** 폰 실제 화면 크기(px)와 dpi */
    private int[] screen() {
        final DisplayMetrics m = new DisplayMetrics();
        ((DisplayManager) getSystemService(DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m);
        return new int[]{m.widthPixels, m.heightPixels, m.densityDpi};
    }

    private void global(final int action) { main.post(() -> performGlobalAction(action)); }

    private void scroll(float x, float y, float W, float H, boolean contentDown) {
        final float d = Math.max(200f, H * 0.25f) / 2f;
        final Path p = new Path();
        p.moveTo(clamp(x, W), clamp(y + (contentDown ? -d : d), H));
        p.lineTo(clamp(x, W), clamp(y + (contentDown ? d : -d), H));
        gesture(p, 150);
    }

    /** 제스처를 차례로 실행 (이미 실행 중이면 줄 세움, 너무 밀리면 버림) */
    private void gesture(Path p, long durMs) {
        final GestureDescription g = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, durMs)).build();
        main.post(() -> {
            if (queue.size() < MAX_QUEUE) queue.add(g);
            pump();
        });
    }

    private void pump() {
        while (!dispatching && !queue.isEmpty()) {
            final GestureDescription g = queue.poll();
            dispatching = true;
            final GestureResultCallback cb = new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) { dispatching = false; pump(); }

                @Override public void onCancelled(GestureDescription d) { dispatching = false; pump(); }
            };
            if (!dispatchGesture(g, cb, main)) dispatching = false;
        }
    }
}
