package com.garpsu.homemanager;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 폰을 gsHomeManager 원격 접속(서버)로 만드는 프로토콜 서버: PC 의 원격 접속(클라이언트)이 붙으면 폰 화면(JPEG)을 보낸다 (화면 보기 전용: PC 의 입력은 무시).
 * 메시지 = 헤더 5바이트(종류 1 + 길이 4, 리틀 엔디언) + 본문 (Session.java 와 같은 프로토콜). 한 번에 클라이언트 한 명.
 * 안드로이드 클래스를 쓰지 않는 순수 자바. TLS 없음: 신뢰하는 내부망에서만 사용할 것.
 */
final class ScreenServer {
    /** 연결 상태를 받는 쪽 */
    interface Host {
        void onClient(String ipOrNull);                     // 클라이언트 연결됨(ip) / 끊김(null)
        void onLog(String s);
    }

    static final int RM_AUTH = 1, RM_FRAME = 2, RM_INPUT = 3, RM_INFO = 4, RM_FILE = 5;
    static final int FT_END = 2, FT_ACK = 4;
    static final int MAX_MSG = 1 << 20;                     // 폰은 파일을 받지 않으므로 큰 메시지는 거부

    private final int port;
    private final byte[] pw;
    private final String allowedIp;
    private final Host host;
    private final AtomicBoolean busy = new AtomicBoolean();
    private final Object wlock = new Object();
    private volatile boolean stopped;
    private volatile ServerSocket ss;
    private volatile Socket cur;
    private volatile OutputStream out;                      // 인증을 마치고 모니터 정보를 보낸 뒤에만 설정 (그 전에는 프레임을 보내지 않음)
    private volatile int w = 0, h = 0;
    private volatile byte[] lastMsg;                        // 마지막 프레임 메시지 (새로 연결된 클라이언트에 바로 보여 주기 위해)
    private volatile int lastLen;

    ScreenServer(int port, String password, String allowedIp, Host host) {
        this.port = port;
        this.pw = password.getBytes(StandardCharsets.UTF_8);
        this.allowedIp = allowedIp == null || allowedIp.trim().isEmpty() ? "any" : allowedIp.trim();
        this.host = host;
    }

    /** 대기 시작 (port 를 열지 못하면 IOException) */
    void start() throws IOException {
        final ServerSocket s = new ServerSocket();
        s.setReuseAddress(true);
        s.bind(new InetSocketAddress(port));
        ss = s;
        final Thread t = new Thread(() -> acceptLoop(s), "srv-accept");
        t.setDaemon(true);
        t.start();
    }

    void stop() {
        stopped = true;
        try { ServerSocket s = ss; if (s != null) s.close(); } catch (IOException ignored) { }
        closeClient();
    }

    private void closeClient() {
        try { Socket s = cur; if (s != null) s.close(); } catch (IOException ignored) { }
    }

    /** 화면 크기 (모니터 정보로 알림). 크기가 바뀌어도 이미 연결된 클라이언트에는 프레임의 JPEG 크기로 반영됨 */
    void setSize(int width, int height) { w = width; h = height; }

    boolean hasClient() { return out != null; }

    /** 프레임 메시지 만들기: buf[0..9) 는 헤더 + 모니터 번호용으로 비워 두고 JPEG 는 buf[9..len) 에 넣어서 호출 */
    void sendFrame(byte[] buf, int len) {
        put32(buf, 1, len - 5);                             // 본문 길이 = 모니터 번호 4 + JPEG
        buf[0] = (byte) RM_FRAME;
        put32(buf, 5, 0);                                   // 모니터 번호 0 (폰은 화면 하나)
        lastMsg = java.util.Arrays.copyOf(buf, len);          // 호출자가 buf 를 다음 화면에 다시 쓰므로 복사
        lastLen = len;
        write(buf, len);
    }

    // ---------------------------------------------------------------- 접속 받기
    private void acceptLoop(ServerSocket s) {
        host.onLog("서버 시작: port " + port);
        while (!stopped) {
            try {
                final Socket c = s.accept();
                if (!busy.compareAndSet(false, true)) {         // 이미 한 명 연결됨
                    try { c.close(); } catch (IOException ignored) { }
                    continue;
                }
                final Thread t = new Thread(() -> serve(c), "srv-client");
                t.setDaemon(true);
                t.start();
            } catch (IOException e) {
                if (!stopped) host.onLog("접속 대기 오류: " + e.getMessage());
                break;
            }
        }
    }

    private void serve(Socket c) {
        String ip = "?";
        boolean connected = false;
        try {
            ip = ((InetSocketAddress) c.getRemoteSocketAddress()).getAddress().getHostAddress();
            if (!allowedIp.equalsIgnoreCase("any") && !allowedIp.equals(ip)) { host.onLog("허용되지 않은 IP 거부: " + ip); return; }
            c.setTcpNoDelay(true);
            c.setKeepAlive(true);
            c.setSoTimeout(5000);                               // 인증 메시지를 5초 안에 보내지 않으면 끊음
            final DataInputStream in = new DataInputStream(c.getInputStream());
            final OutputStream o = c.getOutputStream();

            final byte[] h5 = new byte[5];
            in.readFully(h5);
            final long len = le32(h5, 1);
            if ((h5[0] & 0xFF) != RM_AUTH || len > 256) { host.onLog("잘못된 첫 메시지: " + ip); return; }
            final byte[] p = new byte[(int) len];
            in.readFully(p);
            if (!MessageDigest.isEqual(p, pw)) {
                host.onLog("비밀번호 오류: " + ip);
                Thread.sleep(1000);                             // 대입 공격 지연
                o.write(pack(RM_AUTH, new byte[]{0}));
                o.flush();
                return;
            }
            cur = c;
            synchronized (wlock) {
                o.write(pack(RM_AUTH, new byte[]{1}));
                final ByteBuffer bb = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN);
                final float k = Math.min(1f, 900f / Math.max(Math.max(w, h), 1));      // PC 클라이언트 창 크기용 (세로 폰이 모니터보다 커지지 않게). 프레임 해상도와는 별개
                bb.putInt(1).putInt(Math.max(Math.round(w * k), 1)).putInt(Math.max(Math.round(h * k), 1));
                o.write(pack(RM_INFO, bb.array()));
                final byte[] lm = lastMsg;
                if (lm != null) o.write(lm, 0, lastLen);        // 화면이 멈춰 있어도 연결하자마자 보이게
                o.flush();
                out = o;
            }
            connected = true;
            c.setSoTimeout(0);
            host.onLog("클라이언트 연결: " + ip);
            host.onClient(ip);

            while (true) {
                in.readFully(h5);
                final int type = h5[0] & 0xFF;
                final long n = le32(h5, 1);
                if (n > MAX_MSG) { host.onLog("너무 큰 메시지로 연결 종료"); break; }
                final byte[] b = new byte[(int) n];
                in.readFully(b);
                if (type == RM_FILE && n >= 1 && (b[0] & 0xFF) == FT_END) {
                    write(pack(RM_FILE, new byte[]{(byte) FT_ACK, 0}), 7);     // 폰은 파일을 받지 않음: 저장 실패로 응답
                }
                // 그 밖의 메시지(마우스 / 키 입력, 파일 조각, 명령 등)는 무시: 화면 보기 전용
            }
        } catch (IOException | InterruptedException e) {
            if (!stopped && connected) host.onLog("연결 끊김: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
        } finally {
            out = null;
            cur = null;
            try { c.close(); } catch (IOException ignored) { }
            busy.set(false);
            if (connected) {
                host.onLog("클라이언트 종료: " + ip);
                host.onClient(null);
            }
        }
    }

    private void write(byte[] m, int len) {
        final OutputStream o = out;
        if (o == null) return;
        synchronized (wlock) {
            try {
                o.write(m, 0, len);
                o.flush();
            } catch (IOException e) {
                closeClient();                                  // 읽기 쪽이 끊김을 알아서 정리
            }
        }
    }

    // ---------------------------------------------------------------- 바이트 도우미
    private static byte[] pack(int type, byte[] payload) {
        final byte[] m = new byte[5 + payload.length];
        m[0] = (byte) type;
        put32(m, 1, payload.length);
        System.arraycopy(payload, 0, m, 5, payload.length);
        return m;
    }

    static void put32(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
        b[o + 2] = (byte) (v >> 16);
        b[o + 3] = (byte) (v >> 24);
    }

    private static long le32(byte[] b, int o) {
        return ((b[o] & 0xFFL) | (b[o + 1] & 0xFFL) << 8 | (b[o + 2] & 0xFFL) << 16 | (b[o + 3] & 0xFFL) << 24);
    }
}
