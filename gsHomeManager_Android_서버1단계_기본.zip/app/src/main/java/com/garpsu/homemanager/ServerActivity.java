package com.garpsu.homemanager;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

/** 서버 모드 화면: PC 의 원격 접속(클라이언트)이 이 폰의 화면을 볼 수 있게 함 (보기 전용) (port / 비밀번호 / 허용 IP 설정, 시작 / 종료) */
public class ServerActivity extends Activity {
    private static final int REQ_CAPTURE = 21;
    private EditText etPort, etPw, etIp;
    private TextView status, myIp;
    private Button btnStart;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            ui.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("hm", MODE_PRIVATE);
        final float d = getResources().getDisplayMetrics().density;
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding((int) (28 * d), (int) (28 * d), (int) (28 * d), (int) (28 * d));

        final TextView title = new TextView(this);
        title.setText("폰을 서버로 (PC 에서 이 폰 화면 보기)");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, (int) (12 * d));
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        myIp = new TextView(this);
        myIp.setTextSize(15);
        myIp.setGravity(Gravity.CENTER);
        myIp.setPadding(0, 0, 0, (int) (12 * d));
        root.addView(myIp);

        etPort = field(root, "port", InputType.TYPE_CLASS_NUMBER, prefs.getString("srv_port", "7071"));
        etPw = field(root, "비밀번호 (PC 에서 연결할 때 입력)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD, prefs.getString("srv_pw", ""));
        etIp = field(root, "허용 IP (any = 제한 없음)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, prefs.getString("srv_ip", "any"));

        btnStart = new Button(this);
        btnStart.setOnClickListener(v -> onStartStop());
        root.addView(btnStart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, (int) (12 * d), 0, 0);
        root.addView(status);

        final ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        ui.post(tick);
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
    }

    private EditText field(LinearLayout root, String hint, int type, String value) {
        final EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(type);
        e.setSingleLine(true);
        e.setText(value);
        root.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    private void onStartStop() {
        if (CaptureService.running) {
            CaptureService.stop(this);
            return;
        }
        final String pw = etPw.getText().toString();
        int port;
        try { port = Integer.parseInt(etPort.getText().toString().trim()); } catch (NumberFormatException e) { port = 0; }
        if (port < 1 || port > 65535) { status.setText("port 를 확인하세요."); return; }
        if (pw.isEmpty()) { status.setText("비밀번호를 입력하세요. (비밀번호 없이는 시작할 수 없습니다)"); return; }
        if (pw.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 256) { status.setText("비밀번호가 너무 깁니다."); return; }
        final String ip = etIp.getText().toString().trim();
        prefs.edit().putString("srv_port", String.valueOf(port)).putString("srv_pw", pw).putString("srv_ip", ip.isEmpty() ? "any" : ip).apply();
        final MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);       // "화면 녹화/전송 시작" 허용 창
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_CAPTURE) return;
        if (res != RESULT_OK || data == null) { status.setText("화면 캡처를 허용하지 않아 시작하지 않았습니다."); return; }
        CaptureService.start(this, res, data);
    }

    private void refresh() {
        final boolean run = CaptureService.running;
        btnStart.setText(run ? "서버 종료" : "서버 시작");
        etPort.setEnabled(!run);
        etPw.setEnabled(!run);
        etIp.setEnabled(!run);
        myIp.setText("이 폰의 IP 주소: " + ips());
        final String c = CaptureService.clientIp;
        status.setText(run ? (c != null ? "PC 연결됨: " + c : CaptureService.lastLog) : CaptureService.lastLog);
    }

    private static String ips() {
        final StringBuilder sb = new StringBuilder();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) { if (sb.length() > 0) sb.append(", "); sb.append(a.getHostAddress()); }
            }
        } catch (Exception ignored) { }
        return sb.length() == 0 ? "(Wi-Fi 연결을 확인하세요)" : sb.toString();
    }
}
