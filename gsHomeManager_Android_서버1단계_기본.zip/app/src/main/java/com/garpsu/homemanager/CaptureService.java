package com.garpsu.homemanager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * 폰 화면을 캡처해 PC 의 원격 접속(클라이언트)에 보내는 포그라운드 서비스 (서버 모드).
 * 화면 캡처(MediaProjection) -> JPEG -> ScreenServer. 화면 보기 전용 (PC 에서 온 입력은 무시).
 */
public class CaptureService extends Service implements ScreenServer.Host {
    private static final String CHANNEL = "hm_server";
    private static final int ID = 2;
    private static final int MAX_SIDE = 1280;               // 보내는 화면의 긴 변 (넘으면 줄임)
    private static final int QUALITY = 60;
    private static final int MIN_MS_CLIENT = 66, MIN_MS_IDLE = 1000;   // 프레임 간 최소 간격: 클라이언트 연결 중 (약 15fps) / 없을 때

    static volatile boolean running;
    static volatile String clientIp;                        // 연결된 PC (없으면 null)
    static volatile String lastLog = "";

    private MediaProjection mp;
    private VirtualDisplay vd;
    private ImageReader ir;
    private HandlerThread ht;
    private Handler hd;
    private ScreenServer srv;
    private DisplayManager dm;
    private DisplayManager.DisplayListener dl;
    private int sw, sh, dpi;
    private long lastT;
    private Bitmap bmp;
    private final Buf jpg = new Buf();

    private static final class Buf extends ByteArrayOutputStream {
        Buf() { super(1 << 18); }
        byte[] raw() { return buf; }
    }

    static void start(Context c, int resultCode, Intent data) {
        final Intent i = new Intent(c, CaptureService.class).putExtra("rc", resultCode).putExtra("data", data);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void stop(Context c) { c.stopService(new Intent(c, CaptureService.class)); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (running || intent == null || intent.getParcelableExtra("data") == null) {   // 이미 실행 중이거나 비정상 재시작
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }
        final NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        final Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "원격 접속 서버", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        final PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, ServerActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        final Notification n = b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("HomeManager 서버")
                .setContentText("이 폰의 화면을 PC 에 공유 중입니다")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(ID, n);
        } catch (RuntimeException e) {                       // 권한/상태 문제로 포그라운드가 되지 못하면 화면 캡처도 못 함
            lastLog = "서비스를 시작하지 못했습니다: " + e.getMessage();
            stopSelf();
            return START_NOT_STICKY;
        }

        final SharedPreferences p = getSharedPreferences("hm", MODE_PRIVATE);
        int port;
        try { port = Integer.parseInt(p.getString("srv_port", "7071")); } catch (NumberFormatException e) { port = 7071; }
        ht = new HandlerThread("capture");
        ht.start();
        hd = new Handler(ht.getLooper());
        try {
            final MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            mp = mpm.getMediaProjection(intent.getIntExtra("rc", 0), (Intent) intent.getParcelableExtra("data"));
            if (mp == null) throw new IllegalStateException("화면 캡처 권한을 얻지 못했습니다");
            mp.registerCallback(new MediaProjection.Callback() {     // Android 14 이상은 createVirtualDisplay 전에 필수
                @Override public void onStop() { hd.post(() -> shutdown("화면 캡처가 중지되었습니다")); }
            }, hd);
            srv = new ScreenServer(port, p.getString("srv_pw", ""), p.getString("srv_ip", "any"), this);
            dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
            setupCapture();
            srv.start();
        } catch (IOException e) {
            shutdown("서버를 시작하지 못했습니다 (port " + port + " 사용 중?): " + e.getMessage());
            return START_NOT_STICKY;
        } catch (RuntimeException e) {
            shutdown("서버를 시작하지 못했습니다: " + e.getMessage());
            return START_NOT_STICKY;
        }
        dl = new DisplayManager.DisplayListener() {          // 화면 회전 -> 캡처 크기를 다시 맞춤
            @Override public void onDisplayAdded(int id) { }
            @Override public void onDisplayRemoved(int id) { }
            @Override public void onDisplayChanged(int id) {
                if (id == Display.DEFAULT_DISPLAY && measure()) setupCapture();
            }
        };
        dm.registerDisplayListener(dl, hd);
        running = true;
        lastLog = "서버 대기 중 (port " + port + ")";
        return START_NOT_STICKY;
    }

    /** 폰 화면 크기를 재서 sw / sh / dpi 갱신. 바뀌었으면 true */
    private boolean measure() {
        final DisplayMetrics m = new DisplayMetrics();
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m);
        final float k = Math.min(1f, (float) MAX_SIDE / Math.max(m.widthPixels, m.heightPixels));
        final int w = Math.max(2, Math.round(m.widthPixels * k) & ~1), h = Math.max(2, Math.round(m.heightPixels * k) & ~1);   // 짝수
        final boolean ch = w != sw || h != sh;
        sw = w;
        sh = h;
        dpi = m.densityDpi;
        return ch;
    }

    /** 캡처 크기에 맞는 ImageReader / VirtualDisplay 준비 (처음 또는 회전했을 때) */
    private synchronized void setupCapture() {
        measure();
        final ImageReader old = ir;
        final ImageReader nr = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2);
        nr.setOnImageAvailableListener(this::onImage, hd);
        if (vd == null) {
            vd = mp.createVirtualDisplay("HomeManager", sw, sh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, nr.getSurface(), null, null);
        } else {
            vd.resize(sw, sh, dpi);
            vd.setSurface(nr.getSurface());
        }
        ir = nr;
        bmp = null;
        if (old != null) old.close();
        srv.setSize(sw, sh);
    }

    /** 새 화면이 도착 (캡처 스레드). 간격을 지키려고 기다린 뒤 가장 최근 화면만 JPEG 로 보냄 */
    private void onImage(ImageReader r) {
        final long wait = lastT + (srv.hasClient() ? MIN_MS_CLIENT : MIN_MS_IDLE) - SystemClock.uptimeMillis();
        if (wait > 0) {
            try { Thread.sleep(wait); } catch (InterruptedException e) { return; }
        }
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null || r != ir) return;
            final Image.Plane pl = img.getPlanes()[0];
            final ByteBuffer buf = pl.getBuffer();
            final int bw = pl.getRowStride() / pl.getPixelStride(), w = img.getWidth(), h = img.getHeight();
            if (bmp == null || bmp.getWidth() != bw || bmp.getHeight() != h) bmp = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buf);
            final Bitmap src = bw == w ? bmp : Bitmap.createBitmap(bmp, 0, 0, w, h);      // 줄 끝의 여백 제거
            jpg.reset();
            jpg.write(new byte[9], 0, 9);                    // 헤더 5 + 모니터 번호 4 자리 (ScreenServer 가 채움)
            src.compress(Bitmap.CompressFormat.JPEG, QUALITY, jpg);
            if (src != bmp) src.recycle();
            lastT = SystemClock.uptimeMillis();
            srv.sendFrame(jpg.raw(), jpg.size());
        } catch (RuntimeException ignored) {                 // 회전 중에 닫힌 reader 등: 다음 화면에서 다시
        } finally {
            if (img != null) img.close();
        }
    }

    // ---------------------------------------------------------------- ScreenServer.Host
    @Override public void onClient(String ip) { clientIp = ip; }

    @Override public void onLog(String s) { lastLog = s; }

    private void shutdown(String why) {
        lastLog = why;
        stopSelf();
    }

    @Override public void onDestroy() {
        super.onDestroy();
        running = false;
        clientIp = null;
        if (dm != null && dl != null) dm.unregisterDisplayListener(dl);
        if (srv != null) srv.stop();
        if (vd != null) vd.release();
        if (ir != null) ir.close();
        if (mp != null) mp.stop();
        if (ht != null) ht.quitSafely();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
