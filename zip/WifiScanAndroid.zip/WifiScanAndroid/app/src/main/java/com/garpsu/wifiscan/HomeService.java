package com.garpsu.wifiscan;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * 백그라운드 작업 (포그라운드 서비스, 상단 알림 1개).
 * 1) 귀가 감지: Wi-Fi 연결이 바뀔 때마다 홈 공유기 연결 여부 검사 -> HomeBack / NotHome, 귀가 알림
 * 2) 텔레그램 자동 송신: 정해진 간격마다 현재 위치를 텔레그램으로 전송
 * 3) 카톡 자동 보내기: 정해진 간격마다 위치를 측정해 알림 -> 누르면 카톡 공유 화면 (전송은 사람이)
 * 하나라도 켜져 있으면 실행되고, 모두 꺼지면 종료된다.
 */
public class HomeService extends Service {

    static final String PREF_BG = "bg";                 // "home" 설정: 백그라운드 귀가 감지 켜짐
    static final String PREF_KAKAO = "kakao";           // 카톡 자동 보내기 설정
    static final String KAKAO_PKG = "com.kakao.talk";
    static final String PREF_EMAIL = "email";           // 이메일 자동 송신 설정
    static final String GMAIL_PKG = "com.google.android.gm";
    private static final String ACTION_TG = "com.garpsu.wifiscan.TG_SEND";
    private static final String ACTION_KAKAO = "com.garpsu.wifiscan.KAKAO_SEND";
    private static final String ACTION_EMAIL = "com.garpsu.wifiscan.EMAIL_SEND";
    private static final String CH_EMAIL = "email";     // 이메일 보내기 알림 (소리/팝업)
    private static final int ID_EMAIL = 4;
    private static final String CH_STATUS = "status";   // 상시 알림 (조용히)
    private static final String CH_ALERT = "alert";     // 귀가 알림 (소리/팝업)
    private static final String CH_KAKAO = "kakao";     // 카톡 보내기 알림 (소리/팝업)
    private static final int ID_STATUS = 1, ID_ALERT = 2, ID_KAKAO = 3;
    private static final long AWAY_MIN = 2 * 60 * 1000; // 이 시간 이상 밖에 있다 돌아와야 '귀가'
    private static final long SAFETY = 60 * 1000;        // 혹시 놓친 변화를 위해 1분마다 재검사
    private static final long FIX_TIMEOUT = 30 * 1000;   // 위치 측정 최대 대기

    private ConnectivityManager cm;
    private LocationManager lm;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String homeTitle = "NotHome", homeNote = "";
    private boolean tgBusy, kakaoBusy, emailBusy;

    private final Runnable check = this::evaluate;
    private final Runnable periodic = new Runnable() {
        @Override
        public void run() {
            evaluate();
            handler.postDelayed(this, SAFETY);
        }
    };

    private final ConnectivityManager.NetworkCallback netCb = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onAvailable(Network n) {
            schedule();
        }

        @Override
        public void onLost(Network n) {
            schedule();
        }

        @Override
        public void onCapabilitiesChanged(Network n, NetworkCapabilities c) {
            schedule();
        }
    };

    // ---------- 시작 / 중지 (Activity, 부팅 수신기에서 호출) ----------

    static boolean homeOn(Context c) {
        return c.getSharedPreferences("home", MODE_PRIVATE).getBoolean(PREF_BG, false);
    }

    static boolean tgOn(Context c) {
        return c.getSharedPreferences(TelegramSender.PREF, MODE_PRIVATE).getBoolean("on", false);
    }

    static boolean kakaoOn(Context c) {
        return c.getSharedPreferences(PREF_KAKAO, MODE_PRIVATE).getBoolean("on", false);
    }

    static boolean emailOn(Context c) {
        return c.getSharedPreferences(PREF_EMAIL, MODE_PRIVATE).getBoolean("on", false);
    }

    static boolean anyOn(Context c) {
        return homeOn(c) || tgOn(c) || kakaoOn(c) || emailOn(c);
    }

    // "08:00, 18:30" -> 지금 이후 가장 가까운 시각 (오늘 또는 내일). 형식이 틀리면 0
    static long nextTime(String times, long now) {
        long best = 0;
        for (String s : times.split("[,\\s]+")) {
            int[] hm = parseTime(s);
            if (hm == null) {
                continue;
            }
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.setTimeInMillis(now);
            c.set(java.util.Calendar.HOUR_OF_DAY, hm[0]);
            c.set(java.util.Calendar.MINUTE, hm[1]);
            c.set(java.util.Calendar.SECOND, 0);
            c.set(java.util.Calendar.MILLISECOND, 0);
            if (c.getTimeInMillis() <= now + 30 * 1000) {
                c.add(java.util.Calendar.DAY_OF_MONTH, 1);
            }
            if (best == 0 || c.getTimeInMillis() < best) {
                best = c.getTimeInMillis();
            }
        }
        return best;
    }

    // "8:05" / "08:05" -> {8, 5}, 틀리면 null
    static int[] parseTime(String s) {
        String[] t = s.trim().split(":");
        if (t.length != 2) {
            return null;
        }
        try {
            int h = Integer.parseInt(t[0].trim()), m = Integer.parseInt(t[1].trim());
            return h >= 0 && h < 24 && m >= 0 && m < 60 ? new int[]{h, m} : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // 이메일 설정 -> 화면/알림용 설명 ("매일 08:00, 18:00" 또는 "10분마다")
    static String emailSchedule(SharedPreferences sp) {
        return "times".equals(sp.getString("mode", "interval"))
                ? "매일 " + sp.getString("times", "")
                : TelegramSender.intervalLabel(sp.getInt("interval", 60)) + "마다";
    }

    // 보내는 방식: true = 앱 비밀번호로 자동 발송, false = Gmail 작성 화면(알림)
    static boolean emailSmtp(SharedPreferences sp) {
        return "smtp".equals(sp.getString("send", "compose"));
    }

    // 다음 송신 시각
    static long emailNext(SharedPreferences sp, long now) {
        return "times".equals(sp.getString("mode", "interval"))
                ? nextTime(sp.getString("times", ""), now)
                : now + sp.getInt("interval", 60) * 60 * 1000L;
    }

    // Gmail 작성 화면 (받는 사람, 제목, 내용이 채워진 상태). Gmail이 없으면 다른 메일 앱
    static Intent emailCompose(Context c, String to, String subject, String body) {
        Intent i = new Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:"))
                .putExtra(Intent.EXTRA_EMAIL, to.split("[,;\\s]+"))
                .putExtra(Intent.EXTRA_SUBJECT, subject)
                .putExtra(Intent.EXTRA_TEXT, body)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (c.getPackageManager().getLaunchIntentForPackage(GMAIL_PKG) != null) {
            i.setPackage(GMAIL_PKG);
        }
        return i;
    }

    // 예: "[위치] 할머니 · 11-21 18:00 현재 위치" (보내는 사람 이름이 없으면 이름 생략)
    static String emailSubject(Context c) {
        String who = TelegramSender.senderName(c);
        return "[위치] " + (who.isEmpty() ? "" : who + " · ")
                + new SimpleDateFormat("MM-dd HH:mm", Locale.KOREA).format(new Date()) + " 현재 위치";
    }

    // 설정에 맞게 시작하거나 종료 (이미 실행 중이면 설정을 다시 읽음)
    static void refresh(Context c) {
        if (!tgOn(c)) {
            cancelAlarm(c, ACTION_TG);
        }
        if (!kakaoOn(c)) {
            cancelAlarm(c, ACTION_KAKAO);
        }
        if (!emailOn(c)) {
            cancelAlarm(c, ACTION_EMAIL);
        }
        if (anyOn(c)) {
            Intent i = new Intent(c, HomeService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                c.startForegroundService(i);
            } else {
                c.startService(i);
            }
        } else {
            c.stopService(new Intent(c, HomeService.class));
        }
    }

    // 카톡 공유 화면 (위치 메시지가 채워진 상태)
    static Intent kakaoShare(String text) {
        return new Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, text)
                .setPackage(KAKAO_PKG)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    // ---------- 서비스 ----------

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
        try {
            Notification n = statusNotification("확인 중...", "백그라운드 실행 중");
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(ID_STATUS, n);
            }
        } catch (Exception e) {
            // 위치 권한이 없거나 백그라운드에서 시작이 막힌 경우
            stopSelf();
            return;
        }
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build();
        cm.registerNetworkCallback(req, netCb);
        handler.post(periodic);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (cm == null || !anyOn(this)) {
            cancelAlarm(this, ACTION_TG);
            cancelAlarm(this, ACTION_KAKAO);
            cancelAlarm(this, ACTION_EMAIL);
            stopSelf();
            return START_NOT_STICKY;
        }
        String a = intent == null ? null : intent.getAction();
        schedule();
        scheduleTelegram(ACTION_TG.equals(a));
        scheduleKakao(ACTION_KAKAO.equals(a));
        scheduleEmail(ACTION_EMAIL.equals(a));
        updateStatus();
        return START_STICKY; // 시스템이 종료해도 다시 시작
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (cm != null) {
            try {
                cm.unregisterNetworkCallback(netCb);
            } catch (Exception ignored) {
            }
        }
        if (lm != null) {
            lm.removeUpdates(fixListener);
        }
        if (wake != null && wake.isHeld()) {
            wake.release();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---------- 1) 귀가 감지 ----------

    // 연결 직후에는 공유기 정보가 늦게 갱신되므로 잠시 후 검사
    private void schedule() {
        handler.removeCallbacks(check);
        handler.postDelayed(check, 2000);
    }

    private void evaluate() {
        if (!homeOn(this)) {
            updateStatus();
            return;
        }
        SharedPreferences sp = getSharedPreferences("home", MODE_PRIVATE);
        Set<String> routers = sp.getStringSet("routers", new HashSet<String>());
        String bssid = connectedBssid(this);
        String ssid = null;
        boolean home = false;
        if (bssid != null) {
            for (String s : routers) {
                String[] t = s.split("\\|", 2);
                if (t[0].equals(bssid)) {
                    home = true;
                    ssid = t.length > 1 ? t[1] : "";
                    break;
                }
            }
        }

        // 이전 상태 (서비스가 재시작되어도 이어지도록 저장)
        int prev = sp.getInt("bgState", -1); // -1 모름, 0 NotHome, 1 HomeBack
        long leftAt = sp.getLong("leftAt", 0);
        long now = System.currentTimeMillis();
        SharedPreferences.Editor ed = sp.edit();
        if (home) {
            if (prev == 0 && leftAt > 0 && now - leftAt >= AWAY_MIN) {
                alertHomeBack(ssid);
            }
            ed.putLong("leftAt", 0);
        } else if (prev != 0 || leftAt == 0) {
            ed.putLong("leftAt", now); // 집을 떠난 시각
        }
        ed.putInt("bgState", home ? 1 : 0).apply();

        homeTitle = home ? "HomeBack" : "NotHome";
        if (routers.isEmpty()) {
            homeNote = "등록된 홈 공유기가 없습니다";
        } else if (!locationOn(this)) {
            homeNote = "위치 서비스가 꺼져 있어 공유기를 확인할 수 없습니다";
        } else if (home) {
            homeNote = "홈 공유기 연결됨" + (ssid == null || ssid.isEmpty() ? "" : " · " + ssid);
        } else {
            homeNote = bssid == null ? "Wi-Fi 연결 없음" : "다른 공유기에 연결됨";
        }
        updateStatus();
    }

    // ---------- 2) 텔레그램 자동 송신 ----------

    // 보낼 때가 되었으면 보내고, 아니면 다음 송신 알람만 예약
    private void scheduleTelegram(boolean tick) {
        SharedPreferences sp = getSharedPreferences(TelegramSender.PREF, MODE_PRIVATE);
        if (!sp.getBoolean("on", false)) {
            cancelAlarm(this, ACTION_TG);
            return;
        }
        long next = sp.getLong("next", 0);
        if (!tick && System.currentTimeMillis() < next - 30 * 1000) {
            setAlarm(ACTION_TG, next);
            return;
        }
        if (tgBusy) {
            return;
        }
        tgBusy = true;
        updateStatus();
        fetchLocation(loc -> {
            final String token = sp.getString("token", "");
            final String chats = sp.getString("chats", "");
            new Thread(() -> {
                String err = TelegramSender.send(token, chats, TelegramSender.message(this, loc));
                handler.post(() -> {
                    long now = System.currentTimeMillis();
                    long nx = now + sp.getInt("interval", 10) * 60 * 1000L;
                    sp.edit().putLong("lastTime", now)
                            .putString("lastResult", err == null ? "성공" : "실패: " + err)
                            .putLong("next", nx)
                            .apply();
                    tgBusy = false;
                    if (tgOn(this)) {
                        setAlarm(ACTION_TG, nx);
                    }
                    updateStatus();
                    releaseWakeIfIdle();
                });
            }).start();
        });
    }

    // ---------- 3) 카톡 자동 보내기 (알림 -> 카톡 공유 화면) ----------

    private void scheduleKakao(boolean tick) {
        SharedPreferences sp = getSharedPreferences(PREF_KAKAO, MODE_PRIVATE);
        if (!sp.getBoolean("on", false)) {
            cancelAlarm(this, ACTION_KAKAO);
            return;
        }
        long next = sp.getLong("next", 0);
        if (!tick && System.currentTimeMillis() < next - 30 * 1000) {
            setAlarm(ACTION_KAKAO, next);
            return;
        }
        if (kakaoBusy) {
            return;
        }
        kakaoBusy = true;
        fetchLocation(loc -> new Thread(() -> {
            String msg = TelegramSender.message(this, loc);
            handler.post(() -> {
                long now = System.currentTimeMillis();
                long nx = now + sp.getInt("interval", 10) * 60 * 1000L;
                sp.edit().putLong("lastTime", now).putLong("next", nx).apply();
                kakaoBusy = false;
                if (kakaoOn(this)) {
                    notifyKakao(msg, loc);
                    setAlarm(ACTION_KAKAO, nx);
                }
                updateStatus();
                releaseWakeIfIdle();
            });
        }).start());
    }

    private void notifyKakao(String msg, Location loc) {
        PendingIntent pi = PendingIntent.getActivity(this, 2, kakaoShare(msg),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String time = new SimpleDateFormat("HH:mm", Locale.KOREA).format(new Date());
        Notification.Builder b = builder(CH_KAKAO)
                .setContentTitle("카톡으로 위치 보내기 (" + time + ")")
                .setContentText(loc == null ? "위치를 확인하지 못했습니다. 눌러서 카톡 열기"
                        : "눌러서 받는 사람을 고르고 [전송]하세요")
                .setStyle(new Notification.BigTextStyle().bigText(msg))
                .setContentIntent(pi)
                .setColor(0xFFFEE500)
                .setAutoCancel(true);
        if (Build.VERSION.SDK_INT >= 20) {
            b.addAction(new Notification.Action.Builder(0, "카톡으로 보내기", pi).build());
        }
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        }
        getSystemService(NotificationManager.class).notify(ID_KAKAO, b.build());
    }

    // ---------- 4) 이메일 자동 송신 (알림 -> Gmail 작성 화면) ----------

    private void scheduleEmail(boolean tick) {
        SharedPreferences sp = getSharedPreferences(PREF_EMAIL, MODE_PRIVATE);
        if (!sp.getBoolean("on", false)) {
            cancelAlarm(this, ACTION_EMAIL);
            return;
        }
        long next = sp.getLong("next", 0);
        if (!tick && System.currentTimeMillis() < next - 30 * 1000) {
            setAlarm(ACTION_EMAIL, next);
            return;
        }
        if (emailBusy) {
            return;
        }
        emailBusy = true;
        final boolean smtp = emailSmtp(sp);
        updateStatus();
        fetchLocation(loc -> new Thread(() -> {
            String msg = TelegramSender.message(this, loc);
            // 자동 발송: 앱 비밀번호로 바로 전송 / 작성 화면: 알림만 띄움
            final String err = smtp ? EmailSender.send(sp.getString("from", ""), sp.getString("pass", ""),
                    sp.getString("to", ""), emailSubject(this), msg) : null;
            handler.post(() -> {
                long now = System.currentTimeMillis();
                long nx = emailNext(sp, now);
                SharedPreferences.Editor ed = sp.edit().putLong("lastTime", now).putLong("next", nx);
                if (smtp) {
                    ed.putString("lastResult", err == null ? "성공" : "실패: " + err);
                }
                ed.apply();
                emailBusy = false;
                if (emailOn(this)) {
                    if (!smtp) {
                        notifyEmail(sp.getString("to", ""), msg, loc);
                    }
                    if (nx > 0) {
                        setAlarm(ACTION_EMAIL, nx);
                    }
                }
                updateStatus();
                releaseWakeIfIdle();
            });
        }).start());
    }

    private void notifyEmail(String to, String msg, Location loc) {
        PendingIntent pi = PendingIntent.getActivity(this, 3, emailCompose(this, to, emailSubject(this), msg),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String time = new SimpleDateFormat("HH:mm", Locale.KOREA).format(new Date());
        Notification.Builder b = builder(CH_EMAIL)
                .setContentTitle("이메일로 위치 보내기 (" + time + ")")
                .setContentText(loc == null ? "위치를 확인하지 못했습니다. 눌러서 메일 쓰기"
                        : "받는 사람: " + to + " · 눌러서 [보내기]")
                .setStyle(new Notification.BigTextStyle().bigText("받는 사람: " + to + "\n\n" + msg))
                .setContentIntent(pi)
                .setColor(0xFFD93025)
                .setAutoCancel(true);
        if (Build.VERSION.SDK_INT >= 20) {
            b.addAction(new Notification.Action.Builder(0, "메일 쓰기", pi).build());
        }
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        }
        getSystemService(NotificationManager.class).notify(ID_EMAIL, b.build());
    }

    // ---------- 위치 측정 (텔레그램/카톡/이메일 공용) ----------

    interface LocCallback {
        void done(Location l); // 측정 실패 시 마지막으로 알려진 위치, 그것도 없으면 null
    }

    private final List<LocCallback> waiting = new ArrayList<>();
    private Location best;
    private PowerManager.WakeLock wake;

    private final LocationListener fixListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            if (best == null || l.getAccuracy() < best.getAccuracy()) {
                best = l;
            }
            if (l.getAccuracy() <= 50) { // 충분히 정확하면 바로 사용
                finishFix();
            }
        }

        @Override
        public void onStatusChanged(String p, int s, Bundle b) {
        }

        @Override
        public void onProviderEnabled(String p) {
        }

        @Override
        public void onProviderDisabled(String p) {
        }
    };

    private final Runnable fixTimeout = this::finishFix;

    // 새 위치를 측정 (최대 30초). 측정 중이면 같은 결과를 함께 받음
    private void fetchLocation(LocCallback cb) {
        if (wake == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wifiscan:send");
            wake.acquire(FIX_TIMEOUT + 90 * 1000);
        }
        waiting.add(cb);
        if (waiting.size() > 1) {
            return; // 이미 측정 중
        }
        best = null;
        boolean any = false;
        try {
            for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                if (!lm.isProviderEnabled(p)) {
                    continue;
                }
                Location last = lm.getLastKnownLocation(p);
                if (last != null && (best == null || last.getTime() > best.getTime())) {
                    best = last;
                }
                lm.requestLocationUpdates(p, 1000, 0, fixListener, Looper.getMainLooper());
                any = true;
            }
        } catch (SecurityException ignored) {
        }
        // 마지막 위치가 1분 이내면 그대로 사용
        if (best != null && System.currentTimeMillis() - best.getTime() > 60 * 1000) {
            best = null;
        }
        if (!any || best != null) {
            handler.post(this::finishFix);
        } else {
            handler.postDelayed(fixTimeout, FIX_TIMEOUT);
        }
    }

    private void finishFix() {
        if (waiting.isEmpty()) {
            return;
        }
        handler.removeCallbacks(fixTimeout);
        lm.removeUpdates(fixListener);
        Location l = best;
        if (l == null) { // 새 측정 실패 -> 마지막으로 알려진 위치라도 사용
            try {
                for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                    Location last = lm.getLastKnownLocation(p);
                    if (last != null && (l == null || last.getTime() > l.getTime())) {
                        l = last;
                    }
                }
            } catch (SecurityException ignored) {
            }
        }
        List<LocCallback> cbs = new ArrayList<>(waiting);
        waiting.clear();
        for (LocCallback cb : cbs) {
            cb.done(l);
        }
    }

    private void releaseWakeIfIdle() {
        if (!tgBusy && !kakaoBusy && !emailBusy && waiting.isEmpty() && wake != null) {
            if (wake.isHeld()) {
                wake.release();
            }
            wake = null;
        }
    }

    // ---------- 알람 (화면이 꺼진 절전 상태에서도 깨움) ----------

    private static PendingIntent alarmIntent(Context c, String action) {
        Intent i = new Intent(c, HomeService.class).setAction(action);
        int req = ACTION_TG.equals(action) ? 1 : ACTION_KAKAO.equals(action) ? 2 : 3;
        return PendingIntent.getService(c, req, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void setAlarm(String action, long at) {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = alarmIntent(this, action);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    private static void cancelAlarm(Context c, String action) {
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(alarmIntent(c, action));
    }

    // ---------- 공용 도우미 ----------

    // 지금 연결된 공유기의 BSSID (소문자, 없거나 알 수 없으면 null)
    static String connectedBssid(Context c) {
        WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wm == null || !wm.isWifiEnabled()) {
            return null;
        }
        WifiInfo wi = wm.getConnectionInfo();
        String b = wi == null ? null : wi.getBSSID();
        if (b == null || b.equals("02:00:00:00:00:00")) {
            return null; // 권한/위치 서비스가 없으면 가짜 값이 옴
        }
        return b.toLowerCase(Locale.US);
    }

    static boolean locationOn(Context c) {
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 28) {
            return lm.isLocationEnabled();
        }
        return lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    // ---------- 알림 ----------

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CH_STATUS, "백그라운드 상태", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(
                CH_ALERT, "귀가 알림", NotificationManager.IMPORTANCE_HIGH));
        nm.createNotificationChannel(new NotificationChannel(
                CH_KAKAO, "카톡 보내기 알림", NotificationManager.IMPORTANCE_HIGH));
        nm.createNotificationChannel(new NotificationChannel(
                CH_EMAIL, "이메일 보내기 알림", NotificationManager.IMPORTANCE_HIGH));
    }

    private void updateStatus() {
        boolean home = homeOn(this);
        StringBuilder text = new StringBuilder(home ? homeNote : "");
        String title = home ? homeTitle : "위치 자동 보내기 중";

        SharedPreferences tg = getSharedPreferences(TelegramSender.PREF, MODE_PRIVATE);
        if (tg.getBoolean("on", false)) {
            if (text.length() > 0) {
                text.append(" · ");
            }
            text.append("텔레그램 ").append(TelegramSender.intervalLabel(tg.getInt("interval", 10)))
                    .append("마다");
            long last = tg.getLong("lastTime", 0);
            if (tgBusy) {
                text.append(" (보내는 중...)");
            } else if (last > 0) {
                text.append(" (마지막 ")
                        .append(new SimpleDateFormat("HH:mm", Locale.KOREA).format(new Date(last)))
                        .append(tg.getString("lastResult", "").startsWith("성공") ? " ✓)" : " ✗)");
            }
        }
        SharedPreferences kk = getSharedPreferences(PREF_KAKAO, MODE_PRIVATE);
        if (kk.getBoolean("on", false)) {
            if (text.length() > 0) {
                text.append(" · ");
            }
            text.append("카톡 ").append(TelegramSender.intervalLabel(kk.getInt("interval", 10)))
                    .append("마다 알림");
        }
        SharedPreferences em = getSharedPreferences(PREF_EMAIL, MODE_PRIVATE);
        if (em.getBoolean("on", false)) {
            if (text.length() > 0) {
                text.append(" · ");
            }
            text.append("이메일 ").append(emailSchedule(em));
            if (!emailSmtp(em)) {
                text.append(" 알림");
            } else if (emailBusy) {
                text.append(" 자동 (보내는 중...)");
            } else {
                long last = em.getLong("lastTime", 0);
                text.append(" 자동");
                if (last > 0) {
                    text.append(" (마지막 ")
                            .append(new SimpleDateFormat("HH:mm", Locale.KOREA).format(new Date(last)))
                            .append(em.getString("lastResult", "").startsWith("성공") ? " ✓)" : " ✗)");
                }
            }
        }
        getSystemService(NotificationManager.class)
                .notify(ID_STATUS, statusNotification(title, text.toString()));
    }

    private Notification.Builder builder(String ch) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, ch) : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(PendingIntent.getActivity(this, 0, open,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        return b;
    }

    private Notification statusNotification(String title, String text) {
        return builder(CH_STATUS)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setColor(title.equals("HomeBack") ? 0xFF2E7D32
                        : title.equals("NotHome") ? 0xFFC62828 : 0xFF1976D2)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void alertHomeBack(String ssid) {
        Notification.Builder b = builder(CH_ALERT)
                .setContentTitle("HomeBack")
                .setContentText("집에 도착했습니다" + (ssid == null || ssid.isEmpty() ? "" : " (" + ssid + ")"))
                .setColor(0xFF2E7D32)
                .setAutoCancel(true);
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        }
        getSystemService(NotificationManager.class).notify(ID_ALERT, b.build());
    }
}
