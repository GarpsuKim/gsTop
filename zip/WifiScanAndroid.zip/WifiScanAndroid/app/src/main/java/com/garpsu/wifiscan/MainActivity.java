package com.garpsu.wifiscan;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.DhcpInfo;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.app.TimePickerDialog;
import android.util.Patterns;
import android.widget.Spinner;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends Activity {

    private static final int REQ_PERM = 1, REQ_NOTI = 2;
    private CheckBox bgCheck;
    private Button tgBtn, kakaoBtn, emailBtn, senderBtn, msgShareBtn;
    private LinearLayout msgBox; // (3) 탭: [메시지 공유]를 누르면 보이는 4개 버튼
    private static final int MODE_NONE = 0, MODE_WIFI = 1, MODE_LOC = 3, MODE_LAN = 4;

    private WifiManager wm;
    private LocationManager lm;
    private TextView text, status, statusNote; // text: 가장 최근에 검색을 시작한 탭의 결과 화면
    private LinearLayout wifiRows; // 공유기 체크박스 목록 (탭1)
    private final TextView[] texts = new TextView[3];
    private final Button[] startBtns = new Button[3];
    private final Button[] tabBtns = new Button[3];
    private final LinearLayout[] panels = new LinearLayout[3];
    private int curTab = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int mode = MODE_NONE;
    private int scanId = 0; // 기기 목록 결과가 다른 화면을 덮어쓰지 않게 구분

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (mode == MODE_WIFI) {
                showWifiResults();
            }
        }
    };

    // 10초마다 저장된 공유기에 연결되어 있는지 검사
    private final Runnable homeCheck = new Runnable() {
        @Override
        public void run() {
            checkHome();
            handler.postDelayed(this, 10000);
        }
    };

    private final LocationListener locListener = new LocationListener() {
        // 구형 Android(API 29 이하)에서는 아래 3개도 구현해야 함
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onLocationChanged(Location loc) {
            if (mode == MODE_LOC) {
                showLocation(loc, false);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // 상단: 제목 + 우상단 [종료]
        TextView title = new TextView(this);
        title.setText("와이파이 스캔");
        title.setTextSize(18);
        title.setPadding(30, 0, 0, 0);
        title.setGravity(Gravity.CENTER_VERTICAL);

        Button exit = new Button(this);
        exit.setText("종료");
        exit.setOnClickListener(v -> finish());

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        top.addView(exit, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // HomeBack / NotHome
        status = new TextView(this);
        status.setTextSize(44);
        status.setTypeface(null, Typeface.BOLD);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 30, 0, 0);

        statusNote = new TextView(this);
        statusNote.setTextSize(14);
        statusNote.setTextColor(Color.GRAY);
        statusNote.setGravity(Gravity.CENTER);
        statusNote.setPadding(0, 0, 0, 20);

        // 탭 3개: 홈 공유기 등록 / 기기 목록 / 현재 위치
        final String[] names = {"(1) 홈 공유기 등록", "(2) 기기 목록", "(3) 현재 위치"};
        final Runnable[] starts = {this::wifiScan, this::lanScan, this::location};

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            tabBtns[i] = addButton(tabs, names[i], v -> selectTab(idx));
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(statusNote, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(tabs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 탭마다: [검색시작/재검색] 버튼(탭1만 [저장] 추가) + 결과 화면
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            startBtns[i] = addButton(actions, "검색시작", v -> starts[idx].run());
            if (i == 0) {
                addButton(actions, "저장", v -> saveRouters());
            }
            if (i == 2) {
                addButton(actions, "지도", v -> openMap());
                addButton(actions, "복사", v -> copyLocation());
                addButton(actions, "즉시 공유", v -> shareLocation());
                msgShareBtn = addButton(actions, "메시지 공유", v -> toggleMsgBox());
            }

            texts[i] = new TextView(this);
            texts[i].setTextSize(15);
            texts[i].setPadding(40, 40, 40, 40);
            texts[i].setText("[검색시작]을 눌러 주세요.");

            LinearLayout body = new LinearLayout(this);
            body.setOrientation(LinearLayout.VERTICAL);
            if (i == 0) {
                bgCheck = new CheckBox(this); // 백그라운드 귀가 감지 켜기/끄기
                bgCheck.setText("백그라운드 귀가 감지 (앱을 닫아도 상단 알림으로 표시)");
                bgCheck.setTextSize(15);
                bgCheck.setTypeface(null, Typeface.BOLD);
                bgCheck.setPadding(10, 20, 20, 20);
                bgCheck.setChecked(HomeService.homeOn(this));
                bgCheck.setOnClickListener(v -> setBackground(bgCheck.isChecked()));
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                bp.leftMargin = 30;
                body.addView(bgCheck, bp);

                savedBox = new LinearLayout(this); // 저장된 공유기 목록 (스캔 결과 위)
                savedBox.setOrientation(LinearLayout.VERTICAL);
                body.addView(savedBox);
            }
            body.addView(texts[i]);
            if (i == 0) {
                wifiRows = new LinearLayout(this);
                wifiRows.setOrientation(LinearLayout.VERTICAL);
                body.addView(wifiRows);
            }
            ScrollView scroll = new ScrollView(this);
            scroll.addView(body);

            panels[i] = new LinearLayout(this);
            panels[i].setOrientation(LinearLayout.VERTICAL);
            panels[i].addView(actions, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            if (i == 2) {
                // [메시지 공유]를 눌러야 보이는 4개 버튼 묶음 (처음에는 숨김)
                msgBox = new LinearLayout(this);
                msgBox.setOrientation(LinearLayout.VERTICAL);
                msgBox.setVisibility(View.GONE);
                senderBtn = new Button(this); // 보내는 사람 이름 (모든 위치 메시지 제목에 표시)
                senderBtn.setTextSize(14);
                senderBtn.setOnClickListener(v -> showSenderDialog());
                updateSenderButton();
                msgBox.addView(senderBtn, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                tgBtn = new Button(this); // 텔레그램 자동 송신 설정 (켜짐/꺼짐 표시)
                tgBtn.setTextSize(14);
                tgBtn.setOnClickListener(v -> {
                    // 아직 봇 토큰이 없으면(처음) 설정 도우미부터
                    if (getSharedPreferences(TelegramSender.PREF, MODE_PRIVATE).getString("token", "").isEmpty()) {
                        startActivity(new Intent(this, TelegramSetupActivity.class));
                    } else {
                        showTelegramDialog();
                    }
                });
                updateTgButton();
                msgBox.addView(tgBtn, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                kakaoBtn = new Button(this); // 카톡 자동 보내기 설정 (켜짐/꺼짐 표시)
                kakaoBtn.setTextSize(14);
                kakaoBtn.setOnClickListener(v -> showKakaoDialog());
                updateKakaoButton();
                msgBox.addView(kakaoBtn, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                emailBtn = new Button(this); // 이메일 자동 송신 설정 (켜짐/꺼짐 표시)
                emailBtn.setTextSize(14);
                emailBtn.setOnClickListener(v -> showEmailDialog());
                updateEmailButton();
                msgBox.addView(emailBtn, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                panels[i].addView(msgBox, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            panels[i].addView(scroll, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            root.addView(panels[i], new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        }

        setContentView(root);

        text = texts[0];
        selectTab(0);
        checkHome(); // 실행 처음에 무조건 HomeBack / NotHome 판정
        if (loadRouters().isEmpty()) {
            showIntro(); // 홈 공유기가 아직 없으면 안내 팝업 -> 닫으면 위치 권한 요청
        } else {
            ensurePermission(); // 실행 처음에 위치 권한 요청 (공유기 연결 검사에 필요)
        }
        if (HomeService.anyOn(this) && hasPermission()) {
            HomeService.refresh(this); // 혹시 종료되어 있으면 다시 시작
        }
    }

    // 백그라운드 귀가 감지 켜기/끄기
    private void setBackground(boolean on) {
        if (on) {
            if (!hasPermission()) {
                bgCheck.setChecked(false);
                ensurePermission();
                Toast.makeText(this, "위치 권한을 허용한 뒤 다시 켜 주세요.", Toast.LENGTH_LONG).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
            }
        }
        getSharedPreferences("home", MODE_PRIVATE).edit().putBoolean(HomeService.PREF_BG, on).apply();
        if (on) {
            HomeService.refresh(this);
            Toast.makeText(this, loadRouters().isEmpty()
                    ? "켜졌습니다. 홈 공유기를 먼저 등록하세요."
                    : "켜졌습니다. 앱을 닫아도 귀가를 감지합니다.", Toast.LENGTH_LONG).show();
        } else {
            HomeService.refresh(this);
            Toast.makeText(this, "백그라운드 귀가 감지를 껐습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    // 시작 안내 팝업 (홈 공유기를 등록할 때까지 실행할 때마다 표시)
    private void showIntro() {
        new AlertDialog.Builder(this)
                .setTitle("홈 공유기 등록")
                .setMessage("홈 공유기를 등록하세요.\n\n귀가 할 때 마다 자동으로 검색하여, "
                        + "\"HomeBack\" 또는 \"NotHome\" 상태를 확인합니다.\n\n"
                        + "어린이, 노약자, 치매어르신 들의 안심 귀가 확인에 유용합니다.")
                .setPositiveButton("확인", null)
                .setOnDismissListener(d -> ensurePermission())
                .show();
    }

    private void selectTab(int sel) {
        curTab = sel;
        for (int i = 0; i < 3; i++) {
            panels[i].setVisibility(i == sel ? View.VISIBLE : View.GONE);
            tabBtns[i].setBackgroundColor(i == sel ? 0xFF1976D2 : 0xFFDDDDDD);
            tabBtns[i].setTextColor(i == sel ? Color.WHITE : Color.BLACK);
        }
    }

    private Button addButton(LinearLayout row, String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(4, 0, 4, 0);
        b.setOnClickListener(l);
        row.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, filter);
        }
        handler.post(homeCheck); // 실행 즉시 검사 후 주기적으로 반복
        if (tgBtn != null) {
            updateTgButton(); // 설정 도우미에서 돌아왔을 때 켜짐/꺼짐 갱신
            updateSenderButton();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
        handler.removeCallbacks(homeCheck);
        lm.removeUpdates(locListener);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_NOTI) {
            if (results.length > 0 && results[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "알림 권한이 없으면 귀가 알림이 보이지 않습니다.", Toast.LENGTH_LONG).show();
            }
        } else if (code == REQ_PERM) {
            if (hasPermission()) {
                texts[curTab].setText("[검색시작]을 눌러 주세요.");
                checkHome();
                if (HomeService.anyOn(this)) {
                    HomeService.refresh(this);
                }
            } else {
                texts[curTab].setText("위치 권한이 필요합니다.\n(Wi-Fi 스캔과 위치 확인에 필요합니다.)");
            }
        }
    }

    private boolean hasPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    // 권한이 없으면 요청하고 false 반환
    private boolean ensurePermission() {
        if (hasPermission()) {
            return true;
        }
        // Android 12 이상은 FINE 과 COARSE 를 함께 요청해야 함
        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERM);
        return false;
    }

    // 검색 시작: 해당 탭의 결과 화면을 지우고, 버튼 이름을 [재검색]으로 변경
    private void begin(int newMode, String msg) {
        mode = newMode;
        scanId++;
        lm.removeUpdates(locListener);
        int idx = newMode == MODE_WIFI ? 0 : (newMode == MODE_LAN ? 1 : 2);
        text = texts[idx];
        startBtns[idx].setText("재검색");
        if (newMode == MODE_WIFI) {
            wifiRows.removeAllViews();
            apChecks.clear();
        }
        text.setText(msg);
    }

    // ---------- 홈 공유기 등록 ----------

    private void wifiScan() {
        if (!ensurePermission()) {
            return;
        }
        begin(MODE_WIFI, "스캔 중...");
        if (!wm.isWifiEnabled()) {
            text.setText("Wi-Fi가 꺼져 있습니다.");
            return;
        }
        if (!wm.startScan()) {
            showWifiResults(); // 스캔 횟수 제한 시 마지막 결과 표시
        }
    }

    private static final int C_MARK = 0xFF1976D2;   // ■ 표시 (파랑)
    private static final int C_GOOD = 0xFF2E7D32;   // 강 (초록)
    private static final int C_MID = 0xFFEF6C00;    // 중 (주황)
    private static final int C_BAD = 0xFFC62828;    // 약 (빨강)
    private static final int C_GRAY = 0xFF9E9E9E;

    private final List<CheckBox> apChecks = new ArrayList<>(); // 공유기(BSSID)별 체크박스
    private final Map<String, Integer> seenLevel = new HashMap<>(); // 마지막 스캔: BSSID -> dBm
    private boolean wifiScanned;
    private LinearLayout savedBox;
    private String savedConn = "-"; // 저장 목록을 그릴 때의 연결 공유기 (바뀌면 다시 그림)

    private void showWifiResults() {
        if (!hasPermission()) {
            return;
        }
        List<ScanResult> list = new ArrayList<>(wm.getScanResults());
        Collections.sort(list, (a, b) -> b.level - a.level);

        // 재스캔 결과가 도착해도 사용자가 바꾼 체크 상태를 유지
        Map<String, Boolean> cur = new HashMap<>();
        for (CheckBox cb : apChecks) {
            cur.put(((String[]) cb.getTag())[0], cb.isChecked());
        }
        Map<String, String> saved = loadRouters();
        String conn = connectedBssid();

        // 같은 이름(SSID)끼리 묶기 (신호 센 그룹 순서, 연결 중인 그룹은 맨 위)
        Map<String, List<ScanResult>> groups = new LinkedHashMap<>();
        seenLevel.clear();
        String connSsid = null;
        for (ScanResult r : list) {
            String ssid = ssidOf(r);
            String bssid = r.BSSID.toLowerCase(Locale.US);
            seenLevel.put(bssid, r.level);
            if (bssid.equals(conn)) {
                connSsid = ssid;
            }
            List<ScanResult> g = groups.get(ssid);
            if (g == null) {
                g = new ArrayList<>();
                groups.put(ssid, g);
            }
            g.add(r);
        }
        wifiScanned = true;
        List<String> order = new ArrayList<>(groups.keySet());
        if (connSsid != null) {
            order.remove(connSsid);
            order.add(0, connSsid);
        }

        wifiRows.removeAllViews();
        apChecks.clear();
        text.setText("[ 공유기 " + list.size() + "개 · 이름 " + groups.size() + "개 ]  " + now()
                + (list.isEmpty()
                ? "\n\n결과가 없습니다.\n위치(GPS) 서비스가 켜져 있는지 확인하세요."
                : "\n체크한 공유기를 '저장'으로 등록하세요.\n(이름을 체크하면 같은 이름의 공유기가 모두 체크됩니다)"));

        for (String ssid : order) {
            List<ScanResult> g = groups.get(ssid);
            boolean connGroup = ssid.equals(connSsid);

            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(20, 16, 20, 16);
            if (connGroup) {
                box.setBackgroundColor(0x1A2E7D32);
            }

            // 그룹 머리: ■ 이름 (n개) 📶 연결됨
            final CheckBox head = new CheckBox(this);
            SpannableStringBuilder h = new SpannableStringBuilder();
            append(h, "■ ", C_MARK, true);
            append(h, ssid, 0, true);
            if (g.size() > 1) {
                append(h, "  (" + g.size() + "개)", C_GRAY, false);
            }
            if (connGroup) {
                append(h, "  📶 연결됨", C_GOOD, true);
            }
            head.setText(h);
            head.setTextSize(17);
            box.addView(head);

            final List<CheckBox> kids = new ArrayList<>();
            for (ScanResult r : g) {
                String bssid = r.BSSID.toLowerCase(Locale.US);
                boolean isConn = bssid.equals(conn);
                CheckBox cb = new CheckBox(this);
                cb.setTag(new String[]{bssid, ssid});
                cb.setChecked(cur.containsKey(bssid) ? cur.get(bssid) : saved.containsKey(bssid));

                SpannableStringBuilder s = new SpannableStringBuilder();
                append(s, bssid, 0, false);
                if (isConn) {
                    append(s, "  📶 연결됨", C_GOOD, true);
                }
                s.append('\n');
                appendBars(s, r.level);
                s.append(" ").append(String.valueOf(r.level)).append(" dBm  ")
                        .append(band(r.frequency)).append("  ").append(security(r.capabilities));
                cb.setText(s);
                cb.setTextSize(14);
                cb.setOnCheckedChangeListener((b, c) -> head.setChecked(allChecked(kids)));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.leftMargin = 70;
                box.addView(cb, lp);
                kids.add(cb);
                apChecks.add(cb);
            }
            head.setChecked(allChecked(kids));
            head.setOnClickListener(v -> {
                boolean c = head.isChecked();
                for (CheckBox k : kids) {
                    k.setChecked(c);
                }
            });
            wifiRows.addView(box);
        }
        renderSaved();
    }

    private static String ssidOf(ScanResult r) {
        return (r.SSID == null || r.SSID.isEmpty()) ? "<숨김>" : r.SSID;
    }

    private static boolean allChecked(List<CheckBox> list) {
        for (CheckBox c : list) {
            if (!c.isChecked()) {
                return false;
            }
        }
        return !list.isEmpty();
    }

    private static void append(SpannableStringBuilder sb, String s, int color, boolean bold) {
        int st = sb.length();
        sb.append(s);
        if (color != 0) {
            sb.setSpan(new ForegroundColorSpan(color), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if (bold) {
            sb.setSpan(new StyleSpan(Typeface.BOLD), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    // 신호 세기 막대 ▂▄▆█ (강: 초록, 중: 주황, 약: 빨강) + 강/중/약 글자
    private static void appendBars(SpannableStringBuilder sb, int level) {
        int n = level >= -55 ? 4 : level >= -67 ? 3 : level >= -78 ? 2 : 1;
        int color = n >= 3 ? C_GOOD : n == 2 ? C_MID : C_BAD;
        String bars = "▂▄▆█";
        append(sb, bars.substring(0, n), color, true);
        append(sb, bars.substring(n), 0xFFDDDDDD, true);
        append(sb, n >= 3 ? " 강" : n == 2 ? " 중" : " 약", color, true);
    }

    // 지금 연결된 공유기의 BSSID (없거나 알 수 없으면 null)
    private String connectedBssid() {
        if (!hasPermission() || !wm.isWifiEnabled()) {
            return null;
        }
        String b = wm.getConnectionInfo().getBSSID();
        if (b == null || b.equals("02:00:00:00:00:00")) {
            return null; // 위치 서비스가 꺼져 있으면 가짜 값이 옴
        }
        return b.toLowerCase(Locale.US);
    }

    // 저장된 공유기 목록 (주변에 안 보여도 표시, [삭제] 가능)
    private void renderSaved() {
        String conn = connectedBssid();
        savedConn = String.valueOf(conn);
        savedBox.removeAllViews();
        Map<String, String> saved = loadRouters();

        TextView h = new TextView(this);
        h.setText("저장된 공유기 (" + saved.size() + "개)");
        h.setTextSize(16);
        h.setTypeface(null, Typeface.BOLD);
        h.setPadding(40, 30, 40, 10);
        savedBox.addView(h);

        if (saved.isEmpty()) {
            TextView e = new TextView(this);
            e.setText("없음 — 아래 검색 결과에서 체크 후 [저장]을 누르세요.");
            e.setTextColor(C_GRAY);
            e.setPadding(40, 0, 40, 10);
            savedBox.addView(e);
        }

        List<Map.Entry<String, String>> items = new ArrayList<>(saved.entrySet());
        Collections.sort(items, (a, b) -> {
            int c = a.getValue().compareTo(b.getValue());
            return c != 0 ? c : a.getKey().compareTo(b.getKey());
        });
        for (Map.Entry<String, String> it : items) {
            final String bssid = it.getKey();
            String ssid = it.getValue().isEmpty() ? "<숨김>" : it.getValue();

            SpannableStringBuilder s = new SpannableStringBuilder();
            append(s, "■ ", C_MARK, true);
            append(s, ssid, 0, true);
            s.append("\n").append(bssid).append("\n");
            Integer lv = seenLevel.get(bssid);
            if (bssid.equals(conn)) {
                append(s, "📶 연결됨  ", C_GOOD, true);
            }
            if (lv != null) {
                appendBars(s, lv);
                s.append(" ").append(String.valueOf(lv)).append(" dBm");
            } else if (!bssid.equals(conn)) {
                append(s, wifiScanned ? "주변에 없음" : "검색 전", C_GRAY, false);
            }

            TextView tv = new TextView(this);
            tv.setText(s);
            tv.setTextSize(14);
            Button del = new Button(this);
            del.setText("삭제");
            del.setTextSize(13);
            del.setOnClickListener(v -> deleteRouter(bssid));

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(40, 10, 20, 10);
            if (bssid.equals(conn)) {
                row.setBackgroundColor(0x1A2E7D32);
            }
            row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(del, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            savedBox.addView(row);
        }

        View line = new View(this);
        line.setBackgroundColor(0xFFDDDDDD);
        savedBox.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 3));
    }

    private void deleteRouter(String bssid) {
        Map<String, String> saved = loadRouters();
        saved.remove(bssid);
        writeRouters(saved);
        for (CheckBox cb : apChecks) {
            if (((String[]) cb.getTag())[0].equals(bssid)) {
                cb.setChecked(false);
            }
        }
        Toast.makeText(this, "삭제했습니다 (" + saved.size() + "개 남음)", Toast.LENGTH_SHORT).show();
        renderSaved();
        checkHome();
    }

    private static String band(int f) {
        if (f >= 2400 && f < 2500) {
            return "2.4GHz ch" + (f == 2484 ? 14 : (f - 2407) / 5);
        }
        if (f >= 4900 && f < 5900) {
            return "5GHz ch" + (f - 5000) / 5;
        }
        if (f >= 5925) {
            return "6GHz ch" + (f - 5950) / 5;
        }
        return f + "MHz";
    }

    private static String security(String cap) {
        if (cap == null) return "?";
        if (cap.contains("SAE")) return "WPA3";
        if (cap.contains("WPA2")) return "WPA2";
        if (cap.contains("WPA")) return "WPA";
        if (cap.contains("WEP")) return "WEP";
        return "개방";
    }

    // ---------- 공유기 저장 / 집 감지 ----------

    // 저장된 공유기 (BSSID -> SSID)
    private Map<String, String> loadRouters() {
        Map<String, String> map = new HashMap<>();
        Set<String> set = getSharedPreferences("home", MODE_PRIVATE)
                .getStringSet("routers", new HashSet<String>());
        for (String s : set) {
            String[] t = s.split("\\|", 2);
            map.put(t[0], t.length > 1 ? t[1] : "");
        }
        return map;
    }

    // 화면에 나온 공유기 중 체크한 것은 저장, 체크 해제한 것은 삭제
    private void saveRouters() {
        if (apChecks.isEmpty()) {
            Toast.makeText(this, "먼저 검색을 하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        Map<String, String> saved = loadRouters();
        for (CheckBox cb : apChecks) {
            String[] t = (String[]) cb.getTag();
            if (cb.isChecked()) {
                saved.put(t[0], t[1]);
            } else {
                saved.remove(t[0]);
            }
        }
        writeRouters(saved);
        Toast.makeText(this, "저장되었습니다 (" + saved.size() + "개)", Toast.LENGTH_SHORT).show();
        renderSaved();
        checkHome();
    }

    private void writeRouters(Map<String, String> saved) {
        Set<String> set = new HashSet<>();
        for (Map.Entry<String, String> e : saved.entrySet()) {
            set.add(e.getKey() + "|" + e.getValue());
        }
        getSharedPreferences("home", MODE_PRIVATE).edit().putStringSet("routers", set).apply();
    }

    // 지금 연결된 공유기가 저장된 공유기(BSSID)인지 검사 -> 항상 HomeBack 또는 NotHome 표시
    private void checkHome() {
        Map<String, String> saved = loadRouters();
        boolean home = false;
        String note = "";
        if (saved.isEmpty()) {
            note = "(저장된 공유기가 없습니다)";
        } else if (!hasPermission()) {
            note = "(위치 권한이 필요합니다)";
        } else {
            String cur = connectedBssid();
            home = cur != null && saved.containsKey(cur);
        }
        // 연결된 공유기가 바뀌었으면 저장 목록의 '연결됨' 표시 갱신
        if (!savedConn.equals(String.valueOf(connectedBssid()))) {
            renderSaved();
        }
        status.setText(home ? "HomeBack" : "NotHome");
        status.setTextColor(home ? Color.rgb(46, 125, 50) : Color.rgb(198, 40, 40));
        statusNote.setText(note);
        statusNote.setVisibility(note.isEmpty() ? View.GONE : View.VISIBLE);
    }

    // ---------- 기기 목록 (공유기 대역의 모든 기기, WakeMeOnLan 흉내) ----------

    private static final int[] PROBE = {80, 443, 22, 445, 139, 53, 8080, 62078, 7};

    private static class Dev {
        int num;
        String ip, name = "", mac = "";
        boolean on;
    }

    private void lanScan() {
        begin(MODE_LAN, "기기 탐색 중...");
        DhcpInfo di = wm.getDhcpInfo();
        if (di == null || di.gateway == 0 || di.ipAddress == 0) {
            text.setText("Wi-Fi에 연결되어 있지 않습니다.");
            return;
        }
        // DhcpInfo 값은 리틀엔디언이므로 뒤집어서 사용
        final int my = Integer.reverseBytes(di.ipAddress);
        final int gw = Integer.reverseBytes(di.gateway);
        int m = Integer.reverseBytes(di.netmask);
        if (m == 0 || Integer.bitCount(m) < 24) {
            m = 0xffffff00; // 너무 큰 대역은 /24로 제한
        }
        final int mask = m;
        final int base = my & mask;
        final int last = base | ~mask; // 브로드캐스트 주소
        final String net = toIp(base) + "/" + Integer.bitCount(mask);
        final int id = scanId;
        final SharedPreferences sp = getSharedPreferences("lan", MODE_PRIVATE);
        final Set<String> seen = new HashSet<>(sp.getStringSet("seen", new HashSet<String>()));

        new Thread(() -> {
            ExecutorService ex = Executors.newFixedThreadPool(64);
            try {
                // 1) 응답하는 기기 찾기
                List<Integer> nums = new ArrayList<>();
                List<Future<Boolean>> fs = new ArrayList<>();
                for (int a = base + 1; a < last; a++) {
                    if (a == my) {
                        continue;
                    }
                    final String ip = toIp(a);
                    nums.add(a);
                    fs.add(ex.submit(() -> alive(ip)));
                }
                Map<Integer, Dev> devs = new HashMap<>();
                for (int i = 0; i < fs.size(); i++) {
                    try {
                        if (fs.get(i).get()) {
                            addDev(devs, nums.get(i), true);
                        }
                    } catch (Exception ignored) {
                    }
                }
                addDev(devs, my, true); // 내 폰
                addDev(devs, gw, true); // 공유기

                // 2) 이름(역방향 DNS), MAC(ARP 테이블)
                Map<String, String> arp = readArp();
                Map<Integer, Future<String>> names = new HashMap<>();
                for (Dev d : devs.values()) {
                    final String ip = d.ip;
                    names.put(d.num, ex.submit(() -> hostName(ip)));
                }
                for (Dev d : devs.values()) {
                    try {
                        d.name = names.get(d.num).get();
                    } catch (Exception ignored) {
                    }
                    String mac = arp.get(d.ip);
                    if (mac != null) {
                        d.mac = mac;
                    }
                }

                // 3) 예전에 발견했지만 지금 응답 없는 기기는 OFF(빨강)로 표시
                for (String s : seen) {
                    String[] t = s.split("\\|", -1);
                    if (t.length < 3) {
                        continue;
                    }
                    int n = ipToInt(t[0]);
                    if (n == 0 || (n & mask) != base) {
                        continue;
                    }
                    Dev d = devs.get(n);
                    if (d == null) {
                        d = addDev(devs, n, false);
                    }
                    if (d.name.isEmpty()) {
                        d.name = t[1];
                    }
                    if (d.mac.isEmpty()) {
                        d.mac = t[2];
                    }
                }
                Set<String> save = new HashSet<>();
                for (Dev d : devs.values()) {
                    save.add(d.ip + "|" + d.name + "|" + d.mac);
                }
                sp.edit().putStringSet("seen", save).apply();

                // 4) 표시 (IP 내림차순)
                List<Dev> list = new ArrayList<>(devs.values());
                Collections.sort(list, (x, y) -> Integer.compare(y.num, x.num));
                int on = 0;
                StringBuilder sb = new StringBuilder();
                for (Dev d : list) {
                    if (d.on) {
                        on++;
                    }
                    sb.append(d.on ? "🟢 " : "🔴 ").append(d.ip);
                    if (d.num == gw) {
                        sb.append(" (공유기)");
                    }
                    if (d.num == my) {
                        sb.append(" (내 폰)");
                    }
                    if (!d.name.isEmpty()) {
                        sb.append("  ").append(d.name);
                    }
                    sb.append('\n');
                    if (!d.mac.isEmpty()) {
                        sb.append("      ").append(d.mac).append('\n');
                    }
                }
                String head = "[ " + net + " ]  " + list.size() + " item(s)  🟢 " + on
                        + "  🔴 " + (list.size() - on) + "  " + now() + "\n";
                if (Build.VERSION.SDK_INT >= 29) {
                    head += "(Android 10 이상은 다른 기기의 MAC 주소를 읽을 수 없습니다)\n";
                }
                show(id, head + "\n" + sb);
            } finally {
                ex.shutdownNow();
            }
        }).start();
    }

    private static Dev addDev(Map<Integer, Dev> devs, int num, boolean on) {
        Dev d = devs.get(num);
        if (d == null) {
            d = new Dev();
            d.num = num;
            d.ip = toIp(num);
            devs.put(num, d);
        }
        d.on = d.on || on;
        return d;
    }

    // 화면 갱신 (다른 버튼으로 화면이 바뀐 뒤에는 무시)
    private void show(final int id, final String s) {
        runOnUiThread(() -> {
            if (id == scanId) {
                text.setText(s);
            }
        });
    }

    private static boolean alive(String ip) {
        for (int p : PROBE) {
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(ip, p), 300);
                return true;
            } catch (SocketTimeoutException e) {
                // 응답 없음 -> 다음 포트 시도
            } catch (ConnectException e) {
                String msg = String.valueOf(e.getMessage());
                if (msg.contains("refused") || msg.contains("ECONNREFUSED")) {
                    return true; // 연결 거부 = 기기가 살아있음
                }
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    private static String hostName(String ip) {
        try {
            String h = InetAddress.getByName(ip).getCanonicalHostName();
            return h.equals(ip) ? "" : h;
        } catch (Exception e) {
            return "";
        }
    }

    // Android 9 이하에서만 내용이 채워짐
    private static Map<String, String> readArp() {
        Map<String, String> map = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/net/arp"))) {
            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                String[] t = line.trim().split("\\s+");
                if (t.length >= 4 && !t[3].equals("00:00:00:00:00:00")) {
                    map.put(t[0], t[3].toUpperCase(Locale.US));
                }
            }
        } catch (Exception ignored) {
        }
        return map;
    }

    private static String toIp(int a) {
        return ((a >>> 24) & 0xff) + "." + ((a >> 16) & 0xff) + "." + ((a >> 8) & 0xff) + "." + (a & 0xff);
    }

    private static int ipToInt(String ip) {
        String[] o = ip.split("\\.");
        if (o.length != 4) {
            return 0;
        }
        int r = 0;
        try {
            for (String x : o) {
                r = (r << 8) | (Integer.parseInt(x) & 0xff);
            }
        } catch (NumberFormatException e) {
            return 0;
        }
        return r;
    }

    // ---------- 현재 위치 ----------

    private void location() {
        if (!ensurePermission()) {
            return;
        }
        begin(MODE_LOC, "위치 확인 중...");
        geoLoc = null;

        Location best = null;
        boolean any = false;
        for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
            if (!lm.isProviderEnabled(p)) {
                continue;
            }
            any = true;
            Location l = lm.getLastKnownLocation(p);
            if (l != null && (best == null || l.getTime() > best.getTime())) {
                best = l;
            }
            lm.requestLocationUpdates(p, 1000, 0, locListener);
        }
        if (!any) {
            text.setText("위치(GPS) 서비스가 꺼져 있습니다.");
            return;
        }
        if (best != null) {
            showLocation(best, true);
        }
    }

    private Location geoLoc;      // 주소를 조회한 위치
    private String geoText = "";  // 조회된 주소 문자열
    private boolean geoBusy;

    private Location lastLoc;     // 화면에 표시 중인 위치 (지도/복사/공유에 사용)

    private void showLocation(Location l, boolean cached) {
        lastLoc = l;
        boolean fresh = geoLoc != null && geoLoc.distanceTo(l) < 100;
        text.setText("[ 현재 위치 ]" + (cached ? "  (마지막 위치, 갱신 중...)" : "") + "\n\n"
                + "위도: " + String.format(Locale.US, "%.6f", l.getLatitude()) + "\n"
                + "경도: " + String.format(Locale.US, "%.6f", l.getLongitude()) + "\n"
                + "정확도: " + Math.round(l.getAccuracy()) + " m\n"
                + "제공: " + l.getProvider() + "\n"
                + "시각: " + new SimpleDateFormat("HH:mm:ss", Locale.KOREA).format(new Date(l.getTime()))
                + "\n\n" + (fresh ? geoText : "주소: 조회 중..."));
        if (!fresh && !geoBusy) {
            lookupAddress(l);
        }
    }

    // 위도/경도 -> 주소, 우편번호 (인터넷 필요)
    private void lookupAddress(final Location l) {
        geoBusy = true;
        final int id = scanId;
        new Thread(() -> {
            String r;
            try {
                if (!Geocoder.isPresent()) {
                    r = "주소: 이 기기는 주소 변환을 지원하지 않습니다.";
                } else {
                    List<Address> list = new Geocoder(this, Locale.KOREA)
                            .getFromLocation(l.getLatitude(), l.getLongitude(), 1);
                    if (list == null || list.isEmpty()) {
                        r = "주소: 찾을 수 없습니다.";
                    } else {
                        Address a = list.get(0);
                        String zip = a.getPostalCode() == null ? "(없음)" : a.getPostalCode();
                        r = "주소: " + a.getAddressLine(0) + "\n우편번호: " + zip;
                    }
                }
            } catch (Exception e) {
                r = "주소: 조회 실패 (인터넷 연결을 확인하세요)";
            }
            final String res = r;
            runOnUiThread(() -> {
                geoBusy = false;
                geoLoc = l;
                geoText = res;
                if (mode == MODE_LOC && id == scanId) {
                    showLocation(l, false);
                }
            });
        }).start();
    }

    // ---------- 위치 지도 / 복사 / 공유 ----------

    private boolean needLocation() {
        if (lastLoc == null) {
            Toast.makeText(this, "먼저 [검색시작]으로 위치를 확인하세요.", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    private String latLng() {
        return String.format(Locale.US, "%.6f,%.6f", lastLoc.getLatitude(), lastLoc.getLongitude());
    }

    private String mapUrl() {
        return "https://maps.google.com/?q=" + latLng();
    }

    // 좌표 + (조회된 경우) 주소/우편번호 + 지도 링크
    private String locationText() {
        // 화면에 조회된 주소/우편번호 재사용 (조회 성공 시 geoText = "주소: ...\n우편번호: ...")
        String addr = null, zip = null;
        if (geoLoc != null && geoLoc.distanceTo(lastLoc) < 100 && geoText.contains("우편번호")) {
            for (String line : geoText.split("\n")) {
                if (line.startsWith("주소: ")) {
                    addr = line.substring(4);
                } else if (line.startsWith("우편번호: ") && !line.contains("(없음)")) {
                    zip = line.substring(6);
                }
            }
        }
        return TelegramSender.format(this, lastLoc, addr, zip); // 텔레그램·카톡·이메일과 같은 모양
    }

    // 설치된 지도 앱(구글 지도, 네이버 지도 등)으로 열기, 없으면 브라우저로
    private void openMap() {
        if (needLocation()) {
            return;
        }
        String ll = latLng();
        Intent geo = new Intent(Intent.ACTION_VIEW,
                Uri.parse("geo:" + ll + "?q=" + ll + "(" + Uri.encode("현재 위치") + ")"));
        try {
            startActivity(Intent.createChooser(geo, "지도 앱 선택"));
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(mapUrl())));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "지도를 열 수 있는 앱이 없습니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void copyLocation() {
        if (needLocation()) {
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("현재 위치", locationText()));
        Toast.makeText(this, "위치를 복사했습니다.", Toast.LENGTH_SHORT).show();
    }

    private void shareLocation() {
        if (needLocation()) {
            return;
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "현재 위치");
        send.putExtra(Intent.EXTRA_TEXT, locationText());
        startActivity(Intent.createChooser(send, "위치 공유"));
    }

    // [메시지 공유]: 아래 4개 버튼(보내는 사람/텔레그램/카톡/이메일) 보이기 <-> 숨기기
    private void toggleMsgBox() {
        boolean show = msgBox.getVisibility() != View.VISIBLE;
        msgBox.setVisibility(show ? View.VISIBLE : View.GONE);
        msgShareBtn.setText(show ? "메시지 공유 ▲" : "메시지 공유");
        msgShareBtn.setTextColor(show ? 0xFF1976D2 : Color.BLACK);
    }

    // ---------- 보내는 사람 이름 ----------

    private void updateSenderButton() {
        String who = TelegramSender.senderName(this);
        senderBtn.setText(who.isEmpty() ? "보내는 사람 이름 등록 (예: 할머니)" : "보내는 사람: " + who + "  (변경)");
        senderBtn.setTextColor(who.isEmpty() ? 0xFFC62828 : Color.BLACK);
    }

    private void showSenderDialog() {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(60, 20, 60, 10);
        TextView info = new TextView(this);
        info.setText("받는 사람이 누구의 위치인지 알 수 있게 모든 위치 메시지(텔레그램·카톡·이메일) 맨 위에 표시됩니다.\n\n"
                + "예) 📍 할머니의 현재 위치 (11-21 14:30:05)");
        info.setTextColor(Color.DKGRAY);
        f.addView(info);
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("예: 할머니, 민준이, 아빠");
        name.setText(TelegramSender.senderName(this));
        f.addView(name);
        new AlertDialog.Builder(this)
                .setTitle("보내는 사람 이름")
                .setView(f)
                .setPositiveButton("저장", (d, w) -> {
                    TelegramSender.setSenderName(this, name.getText().toString());
                    updateSenderButton();
                    Toast.makeText(this, "저장했습니다.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    // ---------- 텔레그램 자동 송신 ----------

    private void updateTgButton() {
        SharedPreferences sp = getSharedPreferences(TelegramSender.PREF, MODE_PRIVATE);
        boolean on = sp.getBoolean("on", false);
        tgBtn.setText(on
                ? "텔레그램 자동 송신 (켜짐 · " + TelegramSender.intervalLabel(sp.getInt("interval", 10)) + "마다)"
                : "텔레그램 자동 송신 (꺼짐)");
        tgBtn.setTextColor(on ? 0xFF2E7D32 : Color.BLACK);
    }

    private TextView label(LinearLayout f, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(14);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 24, 0, 4);
        f.addView(t);
        return t;
    }

    // 설정 팝업: 봇 토큰, 받는 사람, 자동 송신 간격, 자동송신시작
    private void showTelegramDialog() {
        final SharedPreferences sp = getSharedPreferences(TelegramSender.PREF, MODE_PRIVATE);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(60, 10, 60, 10);

        // 처음 쓰는 사람용: 단계별 설정 도우미 (누르면 이 팝업을 닫고 도우미 화면으로)
        Button wizard = new Button(this);
        wizard.setText("처음이세요? 설정 도우미 (단계별 안내)");
        wizard.setTextSize(14);
        wizard.setTypeface(null, Typeface.BOLD);
        wizard.setTextColor(0xFF1976D2);
        f.addView(wizard, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        label(f, "봇 토큰");
        final EditText token = new EditText(this);
        token.setSingleLine(true);
        token.setHint("123456789:ABC... (BotFather에서 받은 토큰)");
        token.setText(sp.getString("token", ""));
        // 토큰 칸 + [붙여넣기] (BotFather 메시지 전체를 복사해 와도 토큰만 골라 채움)
        LinearLayout tokenRow = new LinearLayout(this);
        tokenRow.setOrientation(LinearLayout.HORIZONTAL);
        tokenRow.addView(token, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button paste = new Button(this);
        paste.setText("붙여넣기");
        paste.setTextSize(13);
        paste.setOnClickListener(v -> pasteToken(token));
        tokenRow.addView(paste);
        f.addView(tokenRow);

        label(f, "받는 사람 (채팅 ID · 여러 명은 쉼표로 구분)");
        final EditText chats = new EditText(this);
        chats.setSingleLine(true);
        chats.setInputType(InputType.TYPE_CLASS_TEXT);
        chats.setHint("예: 123456789, -100123456789");
        chats.setText(sp.getString("chats", ""));
        f.addView(chats);
        // 등록된 ID 의 이름 (설정 도우미/받는 사람 찾기로 알게 된 이름)
        StringBuilder names = new StringBuilder();
        for (String id : sp.getString("chats", "").split("[,\\s]+")) {
            String nm = id.isEmpty() ? null : TelegramSender.nameOf(this, id);
            if (nm != null) {
                names.append(names.length() > 0 ? ", " : "").append(nm);
            }
        }
        if (names.length() > 0) {
            TextView nv = new TextView(this);
            nv.setText("등록: " + names);
            nv.setTextColor(Color.GRAY);
            nv.setTextSize(12);
            f.addView(nv);
        }
        Button find = new Button(this);
        find.setText("받는 사람 찾기 (봇에게 /start 한 사람·단톡방)");
        find.setTextSize(13);
        find.setOnClickListener(v -> findTelegramChats(token, chats));
        f.addView(find, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Button shareBot = new Button(this);
        shareBot.setText("봇 링크 공유 (받는 사람에게 보내기)");
        shareBot.setTextSize(13);
        shareBot.setOnClickListener(v -> shareBotLink(token));
        f.addView(shareBot, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        label(f, "자동 송신 간격");
        final Spinner interval = new Spinner(this);
        interval.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, TelegramSender.INTERVAL_LABELS));
        int cur = sp.getInt("interval", 10);
        for (int i = 0; i < TelegramSender.INTERVALS.length; i++) {
            if (TelegramSender.INTERVALS[i] == cur) {
                interval.setSelection(i);
            }
        }
        f.addView(interval);

        final CheckBox on = new CheckBox(this);
        on.setText("자동송신시작");
        on.setTextSize(16);
        on.setTypeface(null, Typeface.BOLD);
        on.setChecked(sp.getBoolean("on", false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 24;
        f.addView(on, lp);

        TextView last = new TextView(this);
        long lt = sp.getLong("lastTime", 0);
        last.setText(lt == 0 ? "아직 보낸 적이 없습니다."
                : "마지막 송신: " + new SimpleDateFormat("MM-dd HH:mm:ss", Locale.KOREA).format(new Date(lt))
                + "  " + sp.getString("lastResult", ""));
        last.setTextColor(Color.GRAY);
        last.setPadding(0, 16, 0, 0);
        f.addView(last);

        ScrollView sv = new ScrollView(this);
        sv.addView(f);

        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("텔레그램 자동 송신")
                .setView(sv)
                .setPositiveButton("저장", null)
                .setNeutralButton("지금 보내기", null)
                .setNegativeButton("취소", null)
                .create();
        wizard.setOnClickListener(v -> {
            d.dismiss();
            startActivity(new Intent(this, TelegramSetupActivity.class));
        });
        d.setOnShowListener(x -> {
            // 저장: 입력값 확인 후 저장, 자동송신시작이 체크되어 있으면 실행
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String tk = token.getText().toString().trim();
                String ch = chats.getText().toString().trim();
                int min = TelegramSender.INTERVALS[interval.getSelectedItemPosition()];
                boolean start = on.isChecked();
                if (start && (tk.isEmpty() || ch.isEmpty())) {
                    Toast.makeText(this, "봇 토큰과 받는 사람을 입력하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (start && !hasPermission()) {
                    ensurePermission();
                    Toast.makeText(this, "위치 권한을 허용한 뒤 다시 저장하세요.", Toast.LENGTH_LONG).show();
                    return;
                }
                boolean changed = start && (!sp.getBoolean("on", false) || sp.getInt("interval", 10) != min
                        || !tk.equals(sp.getString("token", "")) || !ch.equals(sp.getString("chats", "")));
                SharedPreferences.Editor ed = sp.edit().putString("token", tk).putString("chats", ch)
                        .putInt("interval", min).putBoolean("on", start);
                if (changed) {
                    ed.putLong("next", 0); // 시작하거나 설정이 바뀌면 바로 1회 전송 후 간격대로
                }
                ed.apply();
                if (start && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(
                        Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
                }
                HomeService.refresh(this);
                updateTgButton();
                Toast.makeText(this, start
                        ? "자동 송신을 시작합니다 (" + TelegramSender.intervalLabel(min) + "마다)"
                        : "저장했습니다. (자동 송신 꺼짐)", Toast.LENGTH_SHORT).show();
                d.dismiss();
            });
            // 지금 보내기: 팝업은 그대로 두고 1회 전송
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                String tk = token.getText().toString().trim();
                String ch = chats.getText().toString().trim();
                if (tk.isEmpty() || ch.isEmpty()) {
                    Toast.makeText(this, "봇 토큰과 받는 사람을 입력하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                sp.edit().putString("token", tk).putString("chats", ch).apply();
                sendTelegramNow(tk, ch, last);
            });
        });
        d.show();
    }

    // 클립보드에서 봇 토큰(숫자:영문 35자 내외)만 찾아 채우기
    private void pasteToken(EditText tokenEdit) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm.getPrimaryClip();
        CharSequence txt = clip != null && clip.getItemCount() > 0 ? clip.getItemAt(0).coerceToText(this) : null;
        if (txt == null || txt.toString().trim().isEmpty()) {
            Toast.makeText(this, "복사된 내용이 없습니다. BotFather 메시지에서 토큰을 먼저 복사하세요.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        String found = TelegramSender.extractToken(txt);
        if (found != null) {
            tokenEdit.setText(found);
            Toast.makeText(this, "봇 토큰을 붙여 넣었습니다.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "복사된 내용에서 봇 토큰을 찾지 못했습니다.\n(형식: 123456789:AAH...)",
                    Toast.LENGTH_LONG).show();
        }
    }

    // 봇 링크(https://t.me/봇아이디)를 카톡·문자 등으로 보내기 -> 받는 사람이 눌러서 [시작]
    private void shareBotLink(EditText tokenEdit) {
        final String tk = tokenEdit.getText().toString().trim();
        if (tk.isEmpty()) {
            Toast.makeText(this, "봇 토큰을 먼저 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "봇 정보 확인 중...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            final String[] err = new String[1];
            final String bot = TelegramSender.botUsername(tk, err);
            runOnUiThread(() -> {
                if (bot == null) {
                    new AlertDialog.Builder(this).setTitle("봇 링크 공유 실패")
                            .setMessage(err[0]).setPositiveButton("확인", null).show();
                    return;
                }
                String text = "📍 위치 알림 받기\n\n"
                        + "아래 링크를 눌러 텔레그램에서 [시작]을 눌러 주세요.\n"
                        + "https://t.me/" + bot + "\n\n"
                        + "단톡방에서 받으려면 아래 링크로 봇을 단톡방에 추가해 주세요.\n"
                        + "https://t.me/" + bot + "?startgroup=true";
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, "위치 알림 받기 (텔레그램)");
                send.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(send, "봇 링크 보내기"));
            });
        }).start();
    }

    // 봇에게 /start 한 사람·단톡방 목록을 가져와 골라서 '받는 사람'에 추가
    private void findTelegramChats(final EditText tokenEdit, final EditText chatsEdit) {
        final String tk = tokenEdit.getText().toString().trim();
        if (tk.isEmpty()) {
            Toast.makeText(this, "봇 토큰을 먼저 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "찾는 중...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            final String[] err = new String[1];
            final List<String[]> found = TelegramSender.findChats(tk, err);
            runOnUiThread(() -> {
                if (err[0] != null) {
                    new AlertDialog.Builder(this).setTitle("받는 사람 찾기 실패")
                            .setMessage(err[0]).setPositiveButton("확인", null).show();
                    return;
                }
                if (found.isEmpty()) {
                    new AlertDialog.Builder(this).setTitle("받는 사람 찾기")
                            .setMessage("찾은 사람이 없습니다.\n\n"
                                    + "1. 받는 사람이 텔레그램에서 봇을 찾아 [시작](/start)을 누르게 하세요.\n"
                                    + "   (단톡방: 봇을 초대한 뒤 단톡방에서 /start 입력)\n"
                                    + "2. 그다음 다시 [받는 사람 찾기]를 누르세요.\n\n"
                                    + "※ 최근 24시간 안에 봇에게 보낸 메시지만 보입니다. "
                                    + "PC 프로그램이 같은 봇으로 메시지를 받고 있으면 안 보일 수 있습니다.")
                            .setPositiveButton("확인", null).show();
                    return;
                }
                // 이미 등록된 ID 는 체크된 상태로 표시
                Set<String> cur = new HashSet<>();
                for (String s : chatsEdit.getText().toString().split("[,\\s]+")) {
                    if (!s.isEmpty()) {
                        cur.add(s);
                    }
                }
                final String[] labels = new String[found.size()];
                final boolean[] checked = new boolean[found.size()];
                for (int i = 0; i < found.size(); i++) {
                    labels[i] = found.get(i)[1] + "\nID: " + found.get(i)[0];
                    checked[i] = cur.contains(found.get(i)[0]);
                }
                new AlertDialog.Builder(this)
                        .setTitle("받는 사람 선택")
                        .setMultiChoiceItems(labels, checked, (dlg, which, isChecked) -> checked[which] = isChecked)
                        .setPositiveButton("추가", (dlg, w) -> {
                            // 기존 목록 순서 유지 + 새로 체크한 것 추가, 체크 해제한 것은 제거
                            java.util.LinkedHashSet<String> ids = new java.util.LinkedHashSet<>();
                            for (String s : chatsEdit.getText().toString().split("[,\\s]+")) {
                                if (!s.isEmpty()) {
                                    ids.add(s);
                                }
                            }
                            for (int i = 0; i < found.size(); i++) {
                                if (checked[i]) {
                                    ids.add(found.get(i)[0]);
                                } else {
                                    ids.remove(found.get(i)[0]);
                                }
                            }
                            chatsEdit.setText(android.text.TextUtils.join(", ", ids));
                        })
                        .setNegativeButton("취소", null)
                        .show();
            });
        }).start();
    }

    // 지금 화면의 위치(없으면 마지막으로 알려진 위치)를 한 번 전송
    private void sendTelegramNow(final String tk, final String ch, final TextView out) {
        Location l = lastLoc;
        if (l == null && hasPermission()) {
            try {
                for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                    Location x = lm.getLastKnownLocation(p);
                    if (x != null && (l == null || x.getTime() > l.getTime())) {
                        l = x;
                    }
                }
            } catch (SecurityException ignored) {
            }
        }
        final Location loc = l;
        out.setText("보내는 중...");
        new Thread(() -> {
            String err = TelegramSender.send(tk, ch, TelegramSender.message(this, loc));
            runOnUiThread(() -> {
                String r = err == null ? "성공" : "실패: " + err;
                out.setText("지금 보내기: " + r);
                Toast.makeText(this, err == null ? "텔레그램으로 보냈습니다." : r, Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    // ---------- 카톡 자동 보내기 (간격마다 알림 -> 누르면 카톡 공유 화면) ----------

    private void updateKakaoButton() {
        SharedPreferences sp = getSharedPreferences(HomeService.PREF_KAKAO, MODE_PRIVATE);
        boolean on = sp.getBoolean("on", false);
        kakaoBtn.setText(on
                ? "카톡 자동 보내기 (켜짐 · " + TelegramSender.intervalLabel(sp.getInt("interval", 10)) + "마다)"
                : "카톡 자동 보내기 (꺼짐)");
        kakaoBtn.setTextColor(on ? 0xFF2E7D32 : Color.BLACK);
    }

    private boolean kakaoInstalled() {
        return getPackageManager().getLaunchIntentForPackage(HomeService.KAKAO_PKG) != null;
    }

    // 설정 팝업: 보내기 간격, 자동보내기시작
    private void showKakaoDialog() {
        final SharedPreferences sp = getSharedPreferences(HomeService.PREF_KAKAO, MODE_PRIVATE);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(60, 10, 60, 10);

        TextView info = new TextView(this);
        info.setText("정해진 간격마다 위치를 확인해 알림을 띄웁니다.\n"
                + "알림을 누르면 위치가 채워진 카톡 화면이 열리고, "
                + "받는 사람을 골라 [전송]을 누르면 보내집니다.\n"
                + "(카톡은 완전 자동 전송을 지원하지 않습니다)");
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, 16, 0, 0);
        f.addView(info);

        label(f, "보내기 간격");
        final Spinner interval = new Spinner(this);
        interval.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, TelegramSender.INTERVAL_LABELS));
        int cur = sp.getInt("interval", 10);
        for (int i = 0; i < TelegramSender.INTERVALS.length; i++) {
            if (TelegramSender.INTERVALS[i] == cur) {
                interval.setSelection(i);
            }
        }
        f.addView(interval);

        final CheckBox on = new CheckBox(this);
        on.setText("자동보내기시작");
        on.setTextSize(16);
        on.setTypeface(null, Typeface.BOLD);
        on.setChecked(sp.getBoolean("on", false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 24;
        f.addView(on, lp);

        TextView last = new TextView(this);
        long lt = sp.getLong("lastTime", 0);
        last.setText(lt == 0 ? "아직 알림을 보낸 적이 없습니다."
                : "마지막 알림: " + new SimpleDateFormat("MM-dd HH:mm:ss", Locale.KOREA).format(new Date(lt)));
        last.setTextColor(Color.GRAY);
        last.setPadding(0, 16, 0, 0);
        f.addView(last);
        if (!kakaoInstalled()) {
            last.setText("카카오톡이 설치되어 있지 않습니다.");
            last.setTextColor(0xFFC62828);
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(f);

        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("카톡 자동 보내기")
                .setView(sv)
                .setPositiveButton("저장", null)
                .setNeutralButton("지금 보내기", null)
                .setNegativeButton("취소", null)
                .create();
        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                int min = TelegramSender.INTERVALS[interval.getSelectedItemPosition()];
                boolean start = on.isChecked();
                if (start && !kakaoInstalled()) {
                    Toast.makeText(this, "카카오톡이 설치되어 있지 않습니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (start && !hasPermission()) {
                    ensurePermission();
                    Toast.makeText(this, "위치 권한을 허용한 뒤 다시 저장하세요.", Toast.LENGTH_LONG).show();
                    return;
                }
                boolean changed = start && (!sp.getBoolean("on", false) || sp.getInt("interval", 10) != min);
                SharedPreferences.Editor ed = sp.edit().putInt("interval", min).putBoolean("on", start);
                if (changed) {
                    ed.putLong("next", 0); // 시작하거나 간격이 바뀌면 바로 1회 알림 후 간격대로
                }
                ed.apply();
                if (start && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(
                        Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
                }
                HomeService.refresh(this);
                updateKakaoButton();
                Toast.makeText(this, start
                        ? "카톡 자동 보내기를 시작합니다 (" + TelegramSender.intervalLabel(min) + "마다 알림)"
                        : "저장했습니다. (카톡 자동 보내기 꺼짐)", Toast.LENGTH_SHORT).show();
                d.dismiss();
            });
            // 지금 보내기: 바로 카톡 공유 화면 열기
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                if (!kakaoInstalled()) {
                    Toast.makeText(this, "카카오톡이 설치되어 있지 않습니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
                last.setText("위치 메시지 만드는 중...");
                sendKakaoNow(d);
            });
        });
        d.show();
    }

    // 지금 화면의 위치(없으면 마지막으로 알려진 위치)로 카톡 공유 화면 열기
    private void sendKakaoNow(final AlertDialog d) {
        final Location loc = currentOrLastLocation();
        new Thread(() -> {
            String msg = TelegramSender.message(this, loc);
            runOnUiThread(() -> {
                d.dismiss();
                try {
                    startActivity(HomeService.kakaoShare(msg));
                } catch (Exception e) {
                    Toast.makeText(this, "카카오톡을 열 수 없습니다.", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    // ---------- 이메일 자동 송신 (정해진 시각/간격마다: 앱 비밀번호로 자동 발송, 또는 알림 -> Gmail 작성 화면) ----------

    private void updateEmailButton() {
        SharedPreferences sp = getSharedPreferences(HomeService.PREF_EMAIL, MODE_PRIVATE);
        boolean on = sp.getBoolean("on", false);
        emailBtn.setText(on
                ? "이메일 자동 송신 (켜짐 · " + HomeService.emailSchedule(sp)
                + (HomeService.emailSmtp(sp) ? " · 자동 발송)" : " · 알림)")
                : "이메일 자동 송신 (꺼짐)");
        emailBtn.setTextColor(on ? 0xFF2E7D32 : Color.BLACK);
    }

    // "8:5, 18:30, 08:05" -> 정렬/중복 제거한 "08:05, 18:30". 틀린 형식이 있으면 null
    private static String normalizeTimes(String s) {
        java.util.TreeSet<String> set = new java.util.TreeSet<>();
        for (String t : s.split("[,\\s]+")) {
            if (t.isEmpty()) {
                continue;
            }
            int[] hm = HomeService.parseTime(t);
            if (hm == null) {
                return null;
            }
            set.add(String.format(Locale.US, "%02d:%02d", hm[0], hm[1]));
        }
        return android.text.TextUtils.join(", ", set);
    }

    // 설정 팝업: 받는 사람, 보내는 시각(지정 시각/일정 간격), 자동송신시작
    private void showEmailDialog() {
        final SharedPreferences sp = getSharedPreferences(HomeService.PREF_EMAIL, MODE_PRIVATE);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(60, 10, 60, 10);

        // 보내는 방식: 자동 발송(앱 비밀번호) / Gmail 작성 화면(알림 -> 직접 보내기)
        label(f, "보내는 방식");
        final RadioGroup how = new RadioGroup(this);
        final RadioButton rSmtp = new RadioButton(this), rCompose = new RadioButton(this);
        rSmtp.setText("완전 자동 발송 (앱 비밀번호)");
        rSmtp.setId(View.generateViewId());
        rCompose.setText("Gmail 작성 화면 (알림 → 직접 [보내기])");
        rCompose.setId(View.generateViewId());
        how.addView(rSmtp);
        how.addView(rCompose);
        f.addView(how);

        final TextView info = new TextView(this);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, 8, 0, 0);
        f.addView(info);

        // 자동 발송 전용: 보내는 이메일 + 앱 비밀번호
        final LinearLayout smtpBox = new LinearLayout(this);
        smtpBox.setOrientation(LinearLayout.VERTICAL);
        label(smtpBox, "보내는 이메일 (내 계정)");
        final EditText from = new EditText(this);
        from.setSingleLine(true);
        from.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        from.setHint("예: mygmail@gmail.com");
        from.setText(sp.getString("from", ""));
        smtpBox.addView(from);
        label(smtpBox, "앱 비밀번호 (16자리)");
        final EditText pass = new EditText(this);
        pass.setSingleLine(true);
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.setHint("abcd efgh ijkl mnop");
        pass.setText(sp.getString("pass", ""));
        smtpBox.addView(pass);
        final CheckBox showPass = new CheckBox(this);
        showPass.setText("비밀번호 보기");
        showPass.setOnCheckedChangeListener((b, c) -> {
            pass.setInputType(InputType.TYPE_CLASS_TEXT | (c
                    ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            pass.setSelection(pass.getText().length());
        });
        smtpBox.addView(showPass);
        TextView help = new TextView(this);
        help.setAutoLinkMask(android.text.util.Linkify.WEB_URLS); // 링크를 눌러 브라우저로 열기 (setText 전에 설정)
        help.setText("앱 비밀번호 만들기 (구글 2단계 인증이 켜져 있어야 함):\n"
                + "https://myaccount.google.com/apppasswords\n"
                + "(네이버: 내정보 → 보안설정 → 2단계 인증 → 애플리케이션 비밀번호, 메일 환경설정에서 SMTP 사용)");
        help.setTextColor(Color.GRAY);
        help.setTextSize(12);
        smtpBox.addView(help);
        f.addView(smtpBox);

        how.setOnCheckedChangeListener((g, id) -> {
            boolean smtp = id == rSmtp.getId();
            smtpBox.setVisibility(smtp ? View.VISIBLE : View.GONE);
            info.setText(smtp
                    ? "정해진 시각마다 위치를 확인해, 알림 없이 바로 메일을 보냅니다."
                    : "정해진 시각마다 위치를 확인해 알림을 띄웁니다. 알림을 누르면 내용이 채워진 "
                    + "Gmail 작성 화면이 열리고, [보내기]를 누르면 보내집니다.");
        });
        how.check(HomeService.emailSmtp(sp) ? rSmtp.getId() : rCompose.getId());

        label(f, "받는 사람 (이메일 · 여러 명은 쉼표로 구분)");
        final EditText to = new EditText(this);
        to.setSingleLine(true);
        to.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        to.setHint("예: friend@gmail.com, family@naver.com");
        to.setText(sp.getString("to", ""));
        f.addView(to);

        label(f, "보내는 시각");
        final RadioGroup mode = new RadioGroup(this);
        final RadioButton rTimes = new RadioButton(this), rInterval = new RadioButton(this);
        rTimes.setText("지정 시각 (매일)");
        rTimes.setId(View.generateViewId());
        rInterval.setText("일정 간격");
        rInterval.setId(View.generateViewId());
        mode.addView(rTimes);
        mode.addView(rInterval);
        f.addView(mode);

        // 지정 시각: 직접 입력 + [시각 추가] (시계에서 고르기)
        final LinearLayout timesRow = new LinearLayout(this);
        timesRow.setOrientation(LinearLayout.HORIZONTAL);
        final EditText times = new EditText(this);
        times.setSingleLine(true);
        times.setHint("예: 08:00, 12:00, 18:00");
        times.setText(sp.getString("times", ""));
        Button addTime = new Button(this);
        addTime.setText("시각 추가");
        addTime.setTextSize(13);
        addTime.setOnClickListener(v -> new TimePickerDialog(this, (tp, h, m) -> {
            String cur = times.getText().toString().trim();
            String add = String.format(Locale.US, "%02d:%02d", h, m);
            String n = normalizeTimes(cur.isEmpty() ? add : cur + ", " + add);
            times.setText(n == null ? cur + ", " + add : n);
        }, 8, 0, true).show());
        timesRow.addView(times, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        timesRow.addView(addTime);
        f.addView(timesRow);

        // 일정 간격
        final Spinner interval = new Spinner(this);
        interval.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, TelegramSender.INTERVAL_LABELS));
        int cur = sp.getInt("interval", 60);
        for (int i = 0; i < TelegramSender.INTERVALS.length; i++) {
            if (TelegramSender.INTERVALS[i] == cur) {
                interval.setSelection(i);
            }
        }
        f.addView(interval);

        mode.setOnCheckedChangeListener((g, id) -> {
            timesRow.setVisibility(id == rTimes.getId() ? View.VISIBLE : View.GONE);
            interval.setVisibility(id == rInterval.getId() ? View.VISIBLE : View.GONE);
        });
        mode.check("times".equals(sp.getString("mode", "times")) ? rTimes.getId() : rInterval.getId());

        final CheckBox on = new CheckBox(this);
        on.setText("자동송신시작");
        on.setTextSize(16);
        on.setTypeface(null, Typeface.BOLD);
        on.setChecked(sp.getBoolean("on", false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 24;
        f.addView(on, lp);

        final TextView last = new TextView(this);
        long lt = sp.getLong("lastTime", 0), nx = sp.getLong("next", 0);
        SimpleDateFormat fmt = new SimpleDateFormat("MM-dd HH:mm", Locale.KOREA);
        boolean wasSmtp = HomeService.emailSmtp(sp);
        last.setText((lt == 0 ? "아직 보낸 적이 없습니다."
                : (wasSmtp ? "마지막 발송: " + fmt.format(new Date(lt)) + "  " + sp.getString("lastResult", "")
                : "마지막 알림: " + fmt.format(new Date(lt))))
                + (sp.getBoolean("on", false) && nx > 0 ? "\n다음 송신: " + fmt.format(new Date(nx)) : ""));
        last.setTextColor(Color.GRAY);
        last.setPadding(0, 16, 0, 0);
        f.addView(last);

        ScrollView sv = new ScrollView(this);
        sv.addView(f);

        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("이메일 자동 송신")
                .setView(sv)
                .setPositiveButton("저장", null)
                .setNeutralButton("지금 보내기", null)
                .setNegativeButton("취소", null)
                .create();
        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String addr = to.getText().toString().trim();
                boolean byTimes = mode.getCheckedRadioButtonId() == rTimes.getId();
                String tm = normalizeTimes(times.getText().toString());
                int min = TelegramSender.INTERVALS[interval.getSelectedItemPosition()];
                boolean start = on.isChecked();
                boolean smtp = how.getCheckedRadioButtonId() == rSmtp.getId();
                String fr = from.getText().toString().trim();
                String pw = pass.getText().toString().replace(" ", "");
                if (!addr.isEmpty() && !validEmails(addr)) {
                    Toast.makeText(this, "이메일 주소 형식을 확인하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!fr.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(fr).matches()) {
                    Toast.makeText(this, "보내는 이메일 형식을 확인하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (start && smtp && (fr.isEmpty() || pw.isEmpty())) {
                    Toast.makeText(this, "보내는 이메일과 앱 비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (byTimes && tm == null) {
                    Toast.makeText(this, "시각은 08:00 처럼 입력하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (start && addr.isEmpty()) {
                    Toast.makeText(this, "받는 사람 이메일을 입력하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (start && byTimes && tm.isEmpty()) {
                    Toast.makeText(this, "보낼 시각을 하나 이상 등록하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (start && !hasPermission()) {
                    ensurePermission();
                    Toast.makeText(this, "위치 권한을 허용한 뒤 다시 저장하세요.", Toast.LENGTH_LONG).show();
                    return;
                }
                SharedPreferences.Editor ed = sp.edit().putString("to", addr)
                        .putString("send", smtp ? "smtp" : "compose")
                        .putString("from", fr).putString("pass", pw)
                        .putString("mode", byTimes ? "times" : "interval")
                        .putString("times", tm == null ? "" : tm)
                        .putInt("interval", min).putBoolean("on", start);
                ed.apply();
                if (start) {
                    // 지정 시각: 다음 시각에 알림 / 일정 간격: 바로 1회 알림 후 간격대로
                    sp.edit().putLong("next", byTimes
                            ? HomeService.nextTime(tm, System.currentTimeMillis()) : 0).apply();
                }
                if (start && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(
                        Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
                }
                HomeService.refresh(this);
                updateEmailButton();
                Toast.makeText(this, start
                        ? "이메일 자동 송신을 시작합니다 (" + HomeService.emailSchedule(sp) + ")"
                        : "저장했습니다. (이메일 자동 송신 꺼짐)", Toast.LENGTH_SHORT).show();
                d.dismiss();
            });
            // 지금 보내기: 자동 발송이면 바로 전송(팝업 유지), 아니면 Gmail 작성 화면 열기
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                String addr = to.getText().toString().trim();
                if (addr.isEmpty() || !validEmails(addr)) {
                    Toast.makeText(this, "받는 사람 이메일을 확인하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                sp.edit().putString("to", addr).apply();
                final Location loc = currentOrLastLocation();
                if (how.getCheckedRadioButtonId() == rSmtp.getId()) {
                    final String fr = from.getText().toString().trim();
                    final String pw = pass.getText().toString().replace(" ", "");
                    if (!Patterns.EMAIL_ADDRESS.matcher(fr).matches() || pw.isEmpty()) {
                        Toast.makeText(this, "보내는 이메일과 앱 비밀번호를 확인하세요.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    sp.edit().putString("from", fr).putString("pass", pw).apply();
                    last.setText("보내는 중...");
                    new Thread(() -> {
                        String err = EmailSender.send(fr, pw, addr, HomeService.emailSubject(this),
                                TelegramSender.message(this, loc));
                        runOnUiThread(() -> {
                            String r = err == null ? "성공" : "실패: " + err;
                            last.setText("지금 보내기: " + r);
                            Toast.makeText(this, err == null ? "메일을 보냈습니다." : r, Toast.LENGTH_LONG).show();
                        });
                    }).start();
                    return;
                }
                last.setText("위치 메시지 만드는 중...");
                new Thread(() -> {
                    String msg = TelegramSender.message(this, loc);
                    runOnUiThread(() -> {
                        d.dismiss();
                        try {
                            startActivity(HomeService.emailCompose(this, addr, HomeService.emailSubject(this), msg));
                        } catch (Exception e) {
                            Toast.makeText(this, "메일 앱을 열 수 없습니다.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }).start();
            });
        });
        d.show();
    }

    private static boolean validEmails(String s) {
        for (String e : s.split("[,;\\s]+")) {
            if (!e.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(e).matches()) {
                return false;
            }
        }
        return true;
    }

    private Location currentOrLastLocation() {
        Location l = lastLoc;
        if (l == null && hasPermission()) {
            try {
                for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                    Location x = lm.getLastKnownLocation(p);
                    if (x != null && (l == null || x.getTime() > l.getTime())) {
                        l = x;
                    }
                }
            } catch (SecurityException ignored) {
            }
        }
        return l;
    }

    private static String now() {
        return new SimpleDateFormat("HH:mm:ss", Locale.KOREA).format(new Date());
    }
}