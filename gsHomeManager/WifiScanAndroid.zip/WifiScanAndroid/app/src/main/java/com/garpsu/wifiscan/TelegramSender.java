package com.garpsu.wifiscan;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 현재 위치를 텔레그램 메시지로 만들어 봇으로 보낸다. (네트워크 사용 -> 작업 스레드에서 호출) */
final class TelegramSender {

    static final String PREF = "tg";
    static final int[] INTERVALS = {5, 10, 15, 30, 60, 180}; // 분
    static final String[] INTERVAL_LABELS = {"5분", "10분", "15분", "30분", "1시간", "3시간"};

    private TelegramSender() {
    }

    static String intervalLabel(int min) {
        for (int i = 0; i < INTERVALS.length; i++) {
            if (INTERVALS[i] == min) {
                return INTERVAL_LABELS[i];
            }
        }
        return min + "분";
    }

    // 위치 -> 메시지 (주소 조회 포함)
    static String message(Context c, Location l) {
        String time = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.KOREA).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append("📍 현재 위치 (").append(time).append(")\n");
        if (l == null) {
            sb.append("위치를 확인할 수 없습니다. (위치 서비스가 켜져 있는지 확인하세요)");
            return sb.toString();
        }
        try {
            if (Geocoder.isPresent()) {
                List<Address> list = new Geocoder(c, Locale.KOREA)
                        .getFromLocation(l.getLatitude(), l.getLongitude(), 1);
                if (list != null && !list.isEmpty()) {
                    Address a = list.get(0);
                    sb.append("주소: ").append(a.getAddressLine(0)).append('\n');
                    if (a.getPostalCode() != null) {
                        sb.append("우편번호: ").append(a.getPostalCode()).append('\n');
                    }
                }
            }
        } catch (Exception ignored) {
        }
        String ll = String.format(Locale.US, "%.6f,%.6f", l.getLatitude(), l.getLongitude());
        sb.append("위도, 경도: ").append(ll.replace(",", ", "))
                .append("  (정확도 ").append(Math.round(l.getAccuracy())).append(" m)\n");
        sb.append("측정: ").append(new SimpleDateFormat("HH:mm:ss", Locale.KOREA).format(new Date(l.getTime())))
                .append('\n');
        sb.append("https://maps.google.com/?q=").append(ll);
        return sb.toString();
    }

    // 받는 사람(쉼표 구분) 모두에게 전송. 성공하면 null, 실패하면 오류 내용
    static String send(String token, String chats, String text) {
        StringBuilder err = new StringBuilder();
        for (String chat : chats.split("[,\\s]+")) {
            if (chat.isEmpty()) {
                continue;
            }
            String e = sendOne(token, chat, text);
            if (e != null) {
                if (err.length() > 0) {
                    err.append(" / ");
                }
                err.append(chat).append(": ").append(e);
            }
        }
        return err.length() == 0 ? null : err.toString();
    }

    private static String sendOne(String token, String chat, String text) {
        HttpURLConnection con = null;
        try {
            URL url = new URL("https://api.telegram.org/bot" + token + "/sendMessage");
            con = (HttpURLConnection) url.openConnection();
            con.setConnectTimeout(15000);
            con.setReadTimeout(15000);
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            String body = "chat_id=" + URLEncoder.encode(chat, "UTF-8")
                    + "&text=" + URLEncoder.encode(text, "UTF-8");
            try (OutputStream os = con.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int code = con.getResponseCode();
            if (code == 200) {
                return null;
            }
            String res = read(con.getErrorStream());
            int i = res.indexOf("\"description\":\"");
            if (i >= 0) {
                int j = res.indexOf('"', i + 15);
                return j > 0 ? res.substring(i + 15, j) : res;
            }
            return "HTTP " + code;
        } catch (Exception e) {
            return "연결 실패 (인터넷 확인)";
        } finally {
            if (con != null) {
                con.disconnect();
            }
        }
    }

    private static String read(InputStream in) {
        if (in == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (Exception ignored) {
        }
        return sb.toString();
    }
}
