@echo off
rem 텔레그램 봇 토큰과 채팅 ID를 입력하세요 (이 파일은 공유하지 마세요)
set BOT_TOKEN=8652608268:AAEou1fQVdp9o7A8Fh6j2_RdzbB6HJ2eNTQ
set CHAT_ID=5943910062
