package com.garpsu.homemanager;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** 폰의 파일(Uri)들을 서버로 차례대로 업로드 (파일 업로드 버튼과 다른 앱에서의 공유가 함께 씀). 한 번에 하나만 실행 */
final class Uploader {
    /** 업로드 진행 중 (세션의 파일 전송은 한 번에 파일 하나만 가능) */
    static final AtomicBoolean busy = new AtomicBoolean();

    interface Callback {
        /** 진행 알림 (작업 스레드). false 를 돌려주면 취소 */
        boolean onProgress(int no, int total, long sent, long size);
        /** 모두 끝남 (작업 스레드). summary = 성공 개수와 실패 사유 */
        void onFinished(String summary);
    }

    /** 이미 업로드 중이면 false */
    static boolean start(final Context ctx, final Session sess, final List<Uri> uris, final Callback cb) {
        if (!busy.compareAndSet(false, true)) return false;
        final Context app = ctx.getApplicationContext();
        final Thread t = new Thread(() -> {
            String summary;
            try {
                summary = run(app, sess, uris, cb);
            } finally {
                busy.set(false);
            }
            cb.onFinished(summary);
        }, "upload");
        t.setDaemon(true);
        t.start();
        return true;
    }

    private static String run(Context ctx, Session sess, List<Uri> uris, Callback cb) {
        final ContentResolver cr = ctx.getContentResolver();
        int ok = 0;
        boolean cancelled = false;
        final StringBuilder fails = new StringBuilder();
        for (int i = 0; i < uris.size() && !sess.isClosed(); i++) {
            final Uri u = uris.get(i);
            String name = "file";
            long size = -1;
            try (Cursor c = cr.query(u, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    if (!c.isNull(0)) name = c.getString(0);
                    if (!c.isNull(1)) size = c.getLong(1);
                }
            } catch (RuntimeException ignored) { }
            final int no = i + 1, total = uris.size();
            if (!cb.onProgress(no, total, 0, Math.max(size, 1))) { cancelled = true; break; }
            File tmp = null;
            String why;
            try {
                InputStream in = cr.openInputStream(u);
                if (in == null) throw new IOException("파일을 열 수 없음");
                if (size < 0) {                                     // 크기를 모르면 임시 파일로 복사해서 크기를 알아냄
                    tmp = File.createTempFile("up", ".tmp", ctx.getCacheDir());
                    try (OutputStream o = new FileOutputStream(tmp)) {
                        byte[] b = new byte[65536];
                        int n;
                        while ((n = in.read(b)) > 0) o.write(b, 0, n);
                    }
                    in.close();
                    size = tmp.length();
                    in = new FileInputStream(tmp);
                }
                try (InputStream fin = in) {
                    final long[] lastUi = {0};
                    why = sess.sendFile(name, size, fin, (sent, tot) -> {
                        final long now = System.currentTimeMillis();
                        if (now - lastUi[0] < 200 && sent != tot) return true;
                        lastUi[0] = now;
                        return cb.onProgress(no, total, sent, tot);
                    });
                }
            } catch (IOException | SecurityException e) {
                why = e.getMessage() == null ? "파일을 읽을 수 없음" : e.getMessage();
            } finally {
                if (tmp != null) //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
            }
            if (why == null) ok++;
            else {
                fails.append("\n- ").append(name).append(": ").append(why);
                if (why.equals("사용자가 취소함")) { cancelled = true; break; }
            }
        }
        return "서버로 보냄: 성공 " + ok + "개 / 전체 " + uris.size() + "개" + (cancelled ? " (취소함)" : "")
                + (fails.length() > 0 ? "\n\n실패:" + fails : "");
    }
}
