package com.garpsu.homemanager;

/**
 * 글자 -> 서버로 보낼 키 (Windows 가상 키 코드). 미국 자판 + 한글 2벌식.
 * 서버는 키 코드만 받으므로 한글은 서버 PC 의 IME 가 조합한다 (한/영 전환은 서버 PC 쪽에서: 도구 줄의 [한/영] 키).
 * 키 토큰 = vk | SHIFT(0x100, Shift 와 함께). 안드로이드 클래스를 쓰지 않는 순수 자바.
 */
final class KeyMap {
    private KeyMap() { }

    static final int SHIFT = 0x100;
    static final int VK_BACK = 0x08, VK_TAB = 0x09, VK_RETURN = 0x0D, VK_SHIFT = 0x10, VK_CONTROL = 0x11, VK_MENU = 0x12,
            VK_CAPITAL = 0x14, VK_HANGUL = 0x15, VK_ESCAPE = 0x1B, VK_SPACE = 0x20, VK_PRIOR = 0x21, VK_NEXT = 0x22, VK_END = 0x23,
            VK_HOME = 0x24, VK_LEFT = 0x25, VK_UP = 0x26, VK_RIGHT = 0x27, VK_DOWN = 0x28, VK_INSERT = 0x2D, VK_DELETE = 0x2E,
            VK_LWIN = 0x5B, VK_F1 = 0x70;

    // 미국 자판의 문장 부호: 기본 / Shift 상태, 같은 순서 (키 코드는 VK_OEM_*)
    private static final String PUNCT = "-=[]\\;',./`";
    private static final String PUNCT_SHIFT = "_+{}|:\"<>?~";
    private static final int[] PUNCT_VK = {0xBD, 0xBB, 0xDB, 0xDD, 0xDC, 0xBA, 0xDE, 0xBC, 0xBE, 0xBF, 0xC0};
    private static final String DIGIT_SHIFT = ")!@#$%^&*(";

    // 한글 호환 자모 U+3131..U+3163 -> 2벌식 키 (대문자 = Shift 와 함께)
    private static final String[] JAMO = {
            "r", "R", "rt", "s", "sw", "sg", "e", "E", "f", "fr", "fa", "fq", "ft", "fx", "fv", "fg", "a", "q", "Q", "qt", "t", "T", "d", "w", "W", "c", "z", "x", "v", "g",   // 3131..314E 자음
            "k", "o", "i", "O", "j", "p", "u", "P", "h", "hk", "ho", "hl", "y", "n", "nj", "np", "nl", "b", "m", "ml", "l"                                                  // 314F..3163 모음
    };
    // 한글 음절 = 초성 19 x 중성 21 x 종성 28. 초성 / 종성이 가리키는 호환 자모
    private static final int[] CHO = {0x3131, 0x3132, 0x3134, 0x3137, 0x3138, 0x3139, 0x3141, 0x3142, 0x3143, 0x3145, 0x3146, 0x3147, 0x3148, 0x3149, 0x314A, 0x314B, 0x314C, 0x314D, 0x314E};
    private static final int[] JONG = {0, 0x3131, 0x3132, 0x3133, 0x3134, 0x3135, 0x3136, 0x3137, 0x3139, 0x313A, 0x313B, 0x313C, 0x313D, 0x313E, 0x313F, 0x3140, 0x3141, 0x3142, 0x3144, 0x3145, 0x3146, 0x3147, 0x3148, 0x314A, 0x314B, 0x314C, 0x314D, 0x314E};

    private static final int[] LETTER_SCAN = {0x1E, 0x30, 0x2E, 0x20, 0x12, 0x21, 0x22, 0x23, 0x17, 0x24, 0x25, 0x26, 0x32, 0x31, 0x18, 0x19, 0x10, 0x13, 0x1F, 0x14, 0x16, 0x2F, 0x11, 0x2D, 0x15, 0x2C};

    /** 글자 하나의 키 토큰 (만들 수 없으면 -1) - 한글은 tokens() 를 쓸 것 */
    static int ascii(char c) {
        if (c >= 'a' && c <= 'z') return 0x41 + (c - 'a');
        if (c >= 'A' && c <= 'Z') return SHIFT | (0x41 + (c - 'A'));
        if (c >= '0' && c <= '9') return c;
        int i = DIGIT_SHIFT.indexOf(c);
        if (i >= 0) return SHIFT | (0x30 + i);
        if (c == ' ') return VK_SPACE;
        if (c == '\n' || c == '\r') return VK_RETURN;
        if (c == '\t') return VK_TAB;
        i = PUNCT.indexOf(c);
        if (i >= 0) return PUNCT_VK[i];
        i = PUNCT_SHIFT.indexOf(c);
        if (i >= 0) return SHIFT | PUNCT_VK[i];
        return -1;
    }

    private static int add(int[] out, int n, String keys) {
        for (int k = 0; k < keys.length(); k++) {
            char c = keys.charAt(k);
            out[n++] = ascii(c);                // 자모 키는 영문자뿐 (대문자 = Shift)
        }
        return n;
    }

    /** 문자열 -> 키 토큰들. 한글 음절 / 자모는 2벌식 키로 풀고, 만들 수 없는 글자(이모지, 한자 등)는 건너뜀 */
    static int[] tokens(CharSequence s) {
        int[] out = new int[s.length() * 6];
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c >= 0xAC00 && c <= 0xD7A3) {   // 한글 음절
                final int idx = c - 0xAC00;
                final int cho = idx / 588, jung = (idx % 588) / 28, jong = idx % 28;
                n = add(out, n, JAMO[CHO[cho] - 0x3131]);
                n = add(out, n, JAMO[0x314F + jung - 0x3131]);
                if (jong != 0) n = add(out, n, JAMO[JONG[jong] - 0x3131]);
            } else if (c >= 0x3131 && c <= 0x3163) {   // 낱자 자모
                n = add(out, n, JAMO[c - 0x3131]);
            } else {
                final int t = ascii(c);
                if (t >= 0) out[n++] = t;
            }
        }
        int[] r = new int[n];
        System.arraycopy(out, 0, r, 0, n);
        return r;
    }

    /** 확장 키 (방향키, Home / End / PgUp / PgDn, Ins / Del) */
    static boolean isExt(int vk) {
        return (vk >= VK_PRIOR && vk <= VK_DOWN) || vk == VK_INSERT || vk == VK_DELETE || vk == VK_LWIN;
    }

    /** 글자가 나오는 키 (Shift 와 함께 누르면 다른 글자) */
    static boolean isPrintable(int vk) {
        return (vk >= 0x30 && vk <= 0x5A) || (vk >= 0xBA && vk <= 0xC0) || (vk >= 0xDB && vk <= 0xDE);
    }

    /** 가상 키 코드 -> 스캔 코드 (미국 자판). 모르면 0 */
    static int scan(int vk) {
        if (vk >= 0x41 && vk <= 0x5A) return LETTER_SCAN[vk - 0x41];
        if (vk >= 0x31 && vk <= 0x39) return 0x02 + (vk - 0x31);
        if (vk == 0x30) return 0x0B;
        switch (vk) {
            case VK_ESCAPE: return 0x01;
            case VK_BACK: return 0x0E;
            case VK_TAB: return 0x0F;
            case VK_RETURN: return 0x1C;
            case VK_CONTROL: return 0x1D;
            case VK_SHIFT: return 0x2A;
            case VK_MENU: return 0x38;
            case VK_SPACE: return 0x39;
            case VK_CAPITAL: return 0x3A;
            case VK_HANGUL: return 0xF2;
            case VK_HOME: return 0x47;
            case VK_UP: return 0x48;
            case VK_PRIOR: return 0x49;
            case VK_LEFT: return 0x4B;
            case VK_RIGHT: return 0x4D;
            case VK_END: return 0x4F;
            case VK_DOWN: return 0x50;
            case VK_NEXT: return 0x51;
            case VK_INSERT: return 0x52;
            case VK_DELETE: return 0x53;
            case 0xBD: return 0x0C;
            case 0xBB: return 0x0D;
            case 0xDB: return 0x1A;
            case 0xDD: return 0x1B;
            case 0xDC: return 0x2B;
            case 0xBA: return 0x27;
            case 0xDE: return 0x28;
            case 0xBC: return 0x33;
            case 0xBE: return 0x34;
            case 0xBF: return 0x35;
            case 0xC0: return 0x29;
            default: return 0;
        }
    }
}
