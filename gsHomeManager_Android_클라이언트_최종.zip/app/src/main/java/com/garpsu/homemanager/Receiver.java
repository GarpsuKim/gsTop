package com.garpsu.homemanager;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 서버가 보낸 파일(로그 파일 등)을 폰에 저장.
 * Android 10 이상: 내려받기 폴더의 Download/HomeManager/날짜(YYYY-MM-DD)/ (파일 앱 / 내 파일에서 보임, 권한 불필요).
 * Android 9 이하: 앱 전용 폴더 Android/data/com.garpsu.homemanager/files/up_down/날짜/.
 * 같은 이름이 있으면 덮어쓰지 않고 이름 뒤에 번호를 붙임.
 */
public class Receiver implements Session.FileSink {
    private final Context ctx;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Uri curUri;                                     // Android 10 이상
    private File curFile;                                   // Android 9 이하
    private String where = "";

    public Receiver(Context c) { ctx = c.getApplicationContext(); }

    /** 파일 이름 정리: 경로 제거, 금지 문자 -> _, 150자 제한 */
    static String safeName(String n) {
        int i = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (i >= 0) n = n.substring(i + 1);
        n = n.replaceAll("[<>:\"/\\\\|?*\\p{Cntrl}]", "_").trim();
        if (n.isEmpty() || n.equals(".") || n.equals("..")) n = "file";
        if (n.length() > 150) n = n.substring(0, 150);
        return n;
    }

    private static String mimeOf(String name) {
        final int d = name.lastIndexOf('.');
        if (d > 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(d + 1).toLowerCase(Locale.ROOT));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    @Override public OutputStream open(String name, long size) throws IOException {
        final String safe = safeName(name);
        final String day = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        curUri = null;
        curFile = null;
        if (Build.VERSION.SDK_INT >= 29) {
            final ContentResolver cr = ctx.getContentResolver();
            final ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(safe));
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/HomeManager/" + day);
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            final Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new IOException("저장할 파일을 만들 수 없음");
            final OutputStream o = cr.openOutputStream(u);
            if (o == null) { cr.delete(u, null, null); throw new IOException("저장할 파일을 열 수 없음"); }
            curUri = u;
            where = "Download/HomeManager/" + day;
            return o;
        }
        final File base = ctx.getExternalFilesDir("up_down");
        if (base == null) throw new IOException("저장 폴더를 만들 수 없음");
        final File dir = new File(base, day);
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("저장 폴더를 만들 수 없음");
        File f = new File(dir, safe);
        final int dot = safe.lastIndexOf('.');
        final String stem = dot > 0 ? safe.substring(0, dot) : safe, ext = dot > 0 ? safe.substring(dot) : "";
        for (int i = 1; f.exists() && i < 1000; i++) f = new File(dir, stem + "_" + i + ext);
        curFile = f;
        where = dir.getPath();
        return new FileOutputStream(f);
    }

    @Override public void done(final String name, boolean ok, long bytes) {
        if (curUri != null) {
            final ContentResolver cr = ctx.getContentResolver();
            try {
                if (ok) {
                    final ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    cr.update(curUri, cv, null, null);
                } else {
                    cr.delete(curUri, null, null);          // 끝나지 않은 파일은 지움
                }
            } catch (RuntimeException ignored) { }
            curUri = null;
        } else if (curFile != null) {
            if (!ok) //noinspection ResultOfMethodCallIgnored
                curFile.delete();
            curFile = null;
        }
        final String msg = ok
                ? "서버에서 받음: " + name + " (" + ((bytes + 1023) / 1024) + " KB)\n" + where
                : "서버 파일 수신 실패: " + name;
        ui.post(() -> Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show());
    }
}
