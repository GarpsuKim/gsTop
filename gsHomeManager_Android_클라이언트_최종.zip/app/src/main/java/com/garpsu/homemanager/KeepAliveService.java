package com.garpsu.homemanager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/**
 * 서버에 연결되어 있는 동안 켜 두는 포그라운드 서비스 (알림 표시).
 * 파일 선택 화면 등 다른 앱을 쓰는 동안 폰이 메모리 부족으로 이 앱을 강제 종료해 연결이 사라지는 것을 막기 위함.
 */
public class KeepAliveService extends Service {
    private static final String CHANNEL = "hm_connection";
    private static final int ID = 1;

    static void start(Context c) {
        final Intent i = new Intent(c, KeepAliveService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (RuntimeException ignored) { }               // 시작하지 못해도 접속 자체는 계속 쓸 수 있음
    }

    static void stop(Context c) { c.stopService(new Intent(c, KeepAliveService.class)); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        final NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        final Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "서버 연결", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        final PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, RemoteActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        final Notification n = b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("HomeManager")
                .setContentText("서버에 연결되어 있습니다")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(ID, n);
        } catch (RuntimeException e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
