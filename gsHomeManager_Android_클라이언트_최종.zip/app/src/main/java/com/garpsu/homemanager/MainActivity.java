package com.garpsu.homemanager;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/** 접속 화면: 서버 IP / port / 비밀번호를 입력하고 연결 (마지막 입력은 이 폰 안에 저장) */
public class MainActivity extends Activity {
    private EditText etIp, etPort, etPw;
    private Button btn;
    private TextView status;
    private LinearLayout historyBox;
    private static final int MAX_HISTORY = 10;
    private SharedPreferences prefs;
    private volatile Session.Pending pending;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("hm", MODE_PRIVATE);

        final float d = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding((int) (28 * d), (int) (28 * d), (int) (28 * d), (int) (28 * d));

        TextView title = new TextView(this);
        title.setText("Home Manager 원격 접속");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, (int) (4 * d));
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView ver = new TextView(this);                      // 버전과 빌드 날짜 / 시각
        ver.setText("버전 " + BuildConfig.VERSION_NAME + "  (빌드 " + BuildConfig.BUILD_TIME + ")");
        ver.setTextSize(13);
        ver.setTextColor(0xFF666666);
        ver.setGravity(Gravity.CENTER);
        ver.setPadding(0, 0, 0, (int) (24 * d));
        root.addView(ver, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        etIp = field(root, "서버 IP (예: 192.168.0.118)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, prefs.getString("ip", ""));
        etPort = field(root, "port", InputType.TYPE_CLASS_NUMBER, prefs.getString("port", "7071"));
        etPw = field(root, "비밀번호", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD, prefs.getString("pw", ""));

        btn = new Button(this);
        btn.setText("연결");
        btn.setOnClickListener(v -> onButton());
        root.addView(btn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, (int) (12 * d), 0, (int) (12 * d));
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        historyBox = new LinearLayout(this);
        historyBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(historyBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        showHistory();

        // 입력 항목들을 화면 가운데에 놓음 (내용이 화면보다 길면 스크롤)
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.addView(root, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.addView(center, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(sv);

        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);   // 연결 중 알림 표시용 (거부해도 접속은 됨)

        final String crash = App.takeCrash(this);               // 지난번에 오류로 종료되었으면 원인을 보여 줌
        if (crash != null) new android.app.AlertDialog.Builder(this)
                .setTitle("지난 실행이 오류로 종료되었습니다")
                .setMessage(crash)
                .setPositiveButton("확인", null)
                .show();
    }

    // ---------------------------------------------------------------- 연결에 성공한 서버 목록 (최근 것이 위, 최대 10개)
    private List<String> loadHistory() {
        List<String> r = new ArrayList<>();
        for (String x : prefs.getString("hist", "").split("\n")) if (x.contains(":") && !x.trim().isEmpty()) r.add(x.trim());
        return r;
    }

    private void saveHistory(List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String x : l) { if (b.length() > 0) b.append('\n'); b.append(x); }
        prefs.edit().putString("hist", b.toString()).apply();
    }

    private void addHistory(String ip, int port, String pw) {
        List<String> l = loadHistory();
        final String e = ip + ":" + port;
        l.remove(e);
        l.add(0, e);
        while (l.size() > MAX_HISTORY) l.remove(l.size() - 1);
        saveHistory(l);
        prefs.edit().putString("pw|" + e, pw).apply();           // 비밀번호는 서버(IP:port)마다 따로 저장
    }

    private void showHistory() {
        historyBox.removeAllViews();
        final List<String> l = loadHistory();
        if (l.isEmpty()) return;
        final float d = getResources().getDisplayMetrics().density;
        TextView t = new TextView(this);
        t.setText("연결했던 서버 (누르면 IP / port / 비밀번호가 입력됩니다)");
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, (int) (8 * d), 0, (int) (4 * d));
        historyBox.addView(t);
        for (final String e : l) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            Button pick = new Button(this);
            pick.setText(e);
            pick.setAllCaps(false);
            pick.setOnClickListener(v -> {
                int i = e.lastIndexOf(':');
                etIp.setText(e.substring(0, i));
                etPort.setText(e.substring(i + 1));
                etPw.setText(prefs.getString("pw|" + e, ""));
            });
            row.addView(pick, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            Button del = new Button(this);
            del.setText("삭제");
            del.setOnClickListener(v -> {
                List<String> cur = loadHistory();
                cur.remove(e);
                saveHistory(cur);
                prefs.edit().remove("pw|" + e).apply();
                showHistory();
            });
            row.addView(del, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            historyBox.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    private EditText field(LinearLayout root, String hint, int type, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(type);
        e.setSingleLine(true);
        e.setText(value);
        root.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    private void onButton() {
        final Session.Pending p = pending;
        if (p != null) { p.cancel(); return; }          // 연결 중이면 취소

        final String ip = etIp.getText().toString().trim();
        final String pw = etPw.getText().toString();
        int port;
        try { port = Integer.parseInt(etPort.getText().toString().trim()); } catch (NumberFormatException e) { port = 0; }
        if (ip.isEmpty() || port < 1 || port > 65535) { status.setText("서버 IP 와 port 를 확인하세요."); return; }
        final int fport = port;

        final Session.Pending np = new Session.Pending();
        pending = np;
        btn.setText("취소");
        status.setText("연결 중... (서버 PC 에서 연결 허용을 눌러야 할 수 있습니다. 최대 60초)");
        new Thread(() -> {
            Session s = null;
            String err = null;
            try {
                s = Session.connect(ip, fport, pw, np);
            } catch (IOException e) {
                err = np.isCancelled() ? "연결을 취소했습니다." : describe(e, ip, fport);
            }
            final Session fs = s;
            final String ferr = err;
            runOnUiThread(() -> done(fs, ferr, ip, fport, pw));
        }, "rdp-connect").start();
    }

    private void done(Session s, String err, String ip, int port, String pw) {
        pending = null;
        btn.setText("연결");
        if (s == null) { status.setText(err); return; }
        status.setText("");
        prefs.edit().putString("ip", ip).putString("port", String.valueOf(port)).putString("pw", pw).apply();
        addHistory(ip, port, pw);
        showHistory();
        Session.current = s;
        KeepAliveService.start(this);                           // 연결되어 있는 동안 앱이 강제 종료되지 않게
        startActivity(new Intent(this, RemoteActivity.class));
    }

    private static String describe(IOException e, String ip, int port) {
        if (e instanceof UnknownHostException) return ip + " 주소를 찾을 수 없습니다.";
        if (e instanceof ConnectException) return ip + ":" + port + " 에 연결할 수 없습니다.\n서버가 켜져 있는지, port 와 방화벽(같은 Wi-Fi 인지)을 확인하세요.";
        if (e instanceof SocketTimeoutException) return "서버가 응답하지 않았습니다. 서버 PC 에서 연결 요청을 확인하세요.";
        final String m = e.getMessage();
        return m == null ? "연결에 실패했습니다." : m;
    }
}
