package com.garpsu.homemanager;

import android.app.Application;
import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 앱이 오류로 갑자기 종료되면 그 원인을 파일에 남기고, 다음에 앱을 열 때 접속 화면에서 보여 줌 (adb 없이 원인을 알기 위해) */
public class App extends Application {
    private static final String CRASH_FILE = "last_crash.txt";

    @Override public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                final StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                final String s = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + "  [" + t.getName() + "]\n" + sw;
                try (FileOutputStream o = new FileOutputStream(new File(getFilesDir(), CRASH_FILE))) {
                    o.write(s.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Throwable ignored) { }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    /** 지난번 종료 원인이 있으면 돌려주고 지움 (없으면 null) */
    static String takeCrash(Context c) {
        final File f = new File(c.getFilesDir(), CRASH_FILE);
        if (!f.isFile()) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            final ByteArrayOutputStream bo = new ByteArrayOutputStream();
            final byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0 && bo.size() < 8000) bo.write(b, 0, n);
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        } finally {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }
}
