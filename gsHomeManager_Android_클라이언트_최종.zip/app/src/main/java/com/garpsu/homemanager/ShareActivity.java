package com.garpsu.homemanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * 다른 앱의 공유 메뉴에서 HomeManager 를 고르면 열림: 이미 서버에 연결되어 있으면 공유한 파일을 바로 서버로 업로드.
 * (연결되어 있지 않으면 안내만 함) 업로드가 끝날 때까지 이 화면을 열어 둠 - 공유한 파일을 읽을 권한이 이 화면이 열려 있는 동안만 유지되기 때문.
 */
public class ShareActivity extends Activity {
    private volatile boolean cancel;
    private AlertDialog dlg;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Session s = Session.current;
        if (s == null || s.isClosed()) {
            Toast.makeText(this, "서버에 연결되어 있지 않습니다.\nHomeManager 에서 먼저 서버에 연결하세요.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        final List<Uri> uris = uris(getIntent());
        if (uris.isEmpty()) {
            Toast.makeText(this, "업로드할 파일이 없습니다. (파일만 공유할 수 있습니다)", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        dlg = new AlertDialog.Builder(this)
                .setMessage("서버로 업로드 준비 중...")
                .setNegativeButton("취소", (d, w) -> cancel = true)
                .setCancelable(false)
                .create();
        dlg.show();
        final boolean started = Uploader.start(this, s, uris, new Uploader.Callback() {
            @Override public boolean onProgress(int no, int total, long sent, long size) {
                final String m = "서버로 업로드 중 (" + no + "/" + total + ", " + (size > 0 ? sent * 100 / size : 100) + "%)";
                runOnUiThread(() -> { if (dlg != null && dlg.isShowing()) dlg.setMessage(m); });
                return !cancel;
            }

            @Override public void onFinished(final String summary) {
                runOnUiThread(() -> {
                    if (dlg != null) dlg.dismiss();
                    if (isFinishing()) return;
                    dlg = new AlertDialog.Builder(ShareActivity.this)
                            .setMessage(summary)
                            .setPositiveButton("확인", (d, w) -> finish())
                            .setCancelable(false)
                            .show();
                });
            }
        });
        if (!started) {
            dlg.dismiss();
            Toast.makeText(this, "다른 업로드가 진행 중입니다. 끝난 뒤 다시 공유하세요.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private static List<Uri> uris(Intent in) {
        final List<Uri> r = new ArrayList<>();
        if (in == null) return r;
        final String act = in.getAction();
        if (Intent.ACTION_SEND_MULTIPLE.equals(act)) {
            final ArrayList<Uri> l = in.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (l != null) r.addAll(l);
        } else if (Intent.ACTION_SEND.equals(act)) {
            final Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) r.add(u);
        }
        if (r.isEmpty()) {                                          // 일부 앱은 ClipData 로만 넘김
            final ClipData cd = in.getClipData();
            if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) if (cd.getItemAt(i).getUri() != null) r.add(cd.getItemAt(i).getUri());
        }
        return r;
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (dlg != null && dlg.isShowing()) dlg.dismiss();
    }
}
