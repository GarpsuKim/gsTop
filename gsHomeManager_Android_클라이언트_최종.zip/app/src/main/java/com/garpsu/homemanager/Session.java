package com.garpsu.homemanager;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * gsHomeManager 원격 접속(서버) 프로토콜 클라이언트 (화면 보기 + 마우스 + 키보드만).
 * 메시지 = 헤더 5바이트(종류 1 + 길이 4, 리틀 엔디언) + 본문. 인증 -> 모니터 정보 -> 화면 프레임(JPEG) / 입력.
 * TLS 없음: 신뢰하는 내부망에서만 사용할 것. 안드로이드 클래스를 쓰지 않는 순수 자바.
 */
public class Session {
    public interface Listener {
        /** 서버가 보낸 화면 한 장 (읽기 스레드). buf[off .. off+len) = JPEG, buf 는 재사용되지 않음 */
        void onFrame(int mon, byte[] buf, int off, int len);
        /** 연결이 끊김 (읽기 스레드). 사용자가 직접 닫은 경우에는 호출되지 않음 */
        void onClosed(String why);
    }

    /** 연결 시도를 중간에 취소하기 위한 손잡이 */
    public static class Pending {
        volatile Socket sock;
        volatile boolean cancelled;
        public boolean isCancelled() { return cancelled; }
        public void cancel() {
            cancelled = true;
            try { Socket s = sock; if (s != null) s.close(); } catch (IOException ignored) { }
        }
    }

    /** 서버가 보내는 파일(로그 파일 등)을 저장하는 쪽 (읽기 스레드에서 호출) */
    public interface FileSink {
        /** 새 파일 시작: 저장할 스트림을 돌려줌 (실패하면 IOException -> 이 파일은 버리고 서버에는 실패로 응답) */
        OutputStream open(String name, long size) throws IOException;
        /** 파일 하나가 끝남. ok = false 이면 불완전한 파일이므로 지울 것 */
        void done(String name, boolean ok, long bytes);
    }

    /** 파일 전송 진행 알림. false 를 돌려주면 전송을 취소 */
    public interface Progress {
        boolean onProgress(long sent, long total);
    }

    static final int RM_AUTH = 1, RM_FRAME = 2, RM_INPUT = 3, RM_INFO = 4, RM_FILE = 5, RM_CMD = 6;
    static final int FT_BEGIN = 0, FT_DATA = 1, FT_END = 2, FT_ABORT = 3, FT_ACK = 4;
    public static final int CMD_GETLOGS = 1, CMD_REBOOT = 2;     // GETLOGS: 서버의 log\*.* 를 보내 줌, REBOOT: 서버 PC 재부팅
    static final int FILE_CHUNK = 64 * 1024, ACK_WAIT_MS = 60000;
    public static final int EV_MOVE = 1, EV_BTN = 2, EV_WHEEL = 3, EV_KEY = 4;
    public static final int BTN_LDOWN = 0x0002, BTN_LUP = 0x0004, BTN_RDOWN = 0x0008, BTN_RUP = 0x0010, BTN_MDOWN = 0x0020, BTN_MUP = 0x0040;
    static final int CONNECT_MS = 10000, APPROVE_MS = 65000, INFO_MS = 10000;   // 서버 사용자가 허용 여부를 누를 때까지 최대 60초
    static final int MAX_MSG = 64 << 20;

    /** 연결에 성공한 세션 (MainActivity -> RemoteActivity 로 넘겨 줌) */
    public static volatile Session current;

    public final int[] monW, monH;
    private final Socket sock;
    private final DataInputStream in;
    private final OutputStream out;
    private final LinkedBlockingQueue<byte[]> q = new LinkedBlockingQueue<>();
    private volatile Listener listener;
    private volatile boolean closed, byUser, started;
    private volatile String ioWhy;                          // 쓰기 쪽에서 먼저 알게 된 연결 오류 (끊김 사유 안내용)
    private volatile FileSink fileSink;
    private final Object ackLock = new Object();
    private int ack = -1;                                   // 서버의 파일 저장 결과: -1 = 아직, 0 = 실패, 1 = 성공 (ackLock 으로 보호)
    // 서버 -> 클라이언트 파일 수신 상태 (읽기 스레드 전용, 한 번에 파일 하나)
    private OutputStream rxOut;
    private String rxName = "";
    private long rxSize, rxGot;
    private boolean rxBad = true;

    private Session(Socket s, DataInputStream in, OutputStream out, int[] w, int[] h) {
        this.sock = s;
        this.in = in;
        this.out = out;
        this.monW = w;
        this.monH = h;
    }

    // ---------------------------------------------------------------- 연결
    /** 접속 -> 인증 -> 모니터 정보까지 (블로킹, 백그라운드 스레드에서 호출). 실패하면 IOException (message = 사용자에게 보여 줄 문장) */
    public static Session connect(String ip, int port, String pw, Pending pend) throws IOException {
        byte[] pwb = pw.getBytes(StandardCharsets.UTF_8);
        if (pwb.length > 256) throw new IOException("비밀번호가 너무 깁니다 (최대 256바이트)");
        Socket s = new Socket();
        pend.sock = s;
        try {
            s.connect(new InetSocketAddress(ip, port), CONNECT_MS);
            if (pend.cancelled) throw new IOException("취소됨");
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            s.setSoTimeout(APPROVE_MS);
            DataInputStream in = new DataInputStream(s.getInputStream());
            OutputStream out = s.getOutputStream();
            out.write(pack(RM_AUTH, pwb, pwb.length));
            out.flush();

            byte[] h = new byte[5];
            in.readFully(h);
            if ((h[0] & 0xFF) != RM_AUTH || le32(h, 1) != 1) throw new IOException("서버가 올바른 응답을 보내지 않았습니다.");
            if (in.readByte() == 0) throw new IOException("인증에 실패했거나 서버가 연결을 거부했습니다.\n비밀번호와 서버의 허용 여부를 확인하세요.");

            s.setSoTimeout(INFO_MS);
            in.readFully(h);
            long len = le32(h, 1);
            if ((h[0] & 0xFF) != RM_INFO || len < 12 || len > 4096 || len % 4 != 0) throw new IOException("서버의 모니터 정보가 올바르지 않습니다.");
            byte[] ib = new byte[(int) len];
            in.readFully(ib);
            ByteBuffer bb = ByteBuffer.wrap(ib).order(ByteOrder.LITTLE_ENDIAN);
            int n = bb.getInt();
            if (n < 1 || n > 16 || n * 2 + 1 > len / 4) throw new IOException("서버의 모니터 정보가 올바르지 않습니다.");
            int[] w = new int[n], hh = new int[n];
            for (int i = 0; i < n; i++) {
                w[i] = bb.getInt();
                hh[i] = bb.getInt();
                if (w[i] < 1 || hh[i] < 1) throw new IOException("서버의 모니터 정보가 올바르지 않습니다.");
            }
            s.setSoTimeout(0);
            return new Session(s, in, out, w, hh);
        } catch (IOException e) {
            try { s.close(); } catch (IOException ignored) { }
            throw e;
        }
    }

    /** 서버가 보내는 파일을 받을 곳 (start 전에 지정). 없으면 받은 파일은 실패로 응답하고 버림 */
    public void setFileSink(FileSink s) { fileSink = s; }

    /** 읽기 / 쓰기 스레드 시작 (화면을 받을 준비가 되면 호출) */
    public synchronized void start(Listener l) {
        listener = l;
        if (started) return;                    // 화면이 다시 만들어져도 읽기 / 쓰기 스레드를 또 만들지 않음 (둘이 같은 소켓을 읽으면 데이터가 깨져 연결이 끊김)
        started = true;
        Thread rx = new Thread(this::readLoop, "rdp-rx");
        rx.setDaemon(true);
        rx.start();
        Thread tx = new Thread(this::writeLoop, "rdp-tx");
        tx.setDaemon(true);
        tx.start();
    }

    /** 사용자가 연결을 끊음 */
    public synchronized void close() {
        byUser = true;
        shutdown();
    }

    private synchronized void shutdown() {
        if (closed) return;
        closed = true;
        try { sock.close(); } catch (IOException ignored) { }
        q.offer(new byte[0]);                   // 쓰기 스레드를 깨움
    }

    public boolean isClosed() { return closed; }

    // ---------------------------------------------------------------- 받기 / 보내기 스레드
    private void readLoop() {
        String why = "서버 또는 네트워크가 연결을 끊었습니다.";
        try {
            byte[] h = new byte[5];
            while (true) {
                in.readFully(h);
                final int type = h[0] & 0xFF;
                final long len = le32(h, 1);
                if (len > MAX_MSG) { why = "서버가 너무 큰 메시지를 보냈습니다."; break; }
                byte[] buf = new byte[(int) len];
                in.readFully(buf);
                if (type == RM_FRAME && len > 4) {
                    final int idx = (buf[0] & 0xFF) | (buf[1] & 0xFF) << 8 | (buf[2] & 0xFF) << 16 | (buf[3] & 0xFF) << 24;
                    final Listener l = listener;
                    if (l != null && idx >= 0 && idx < monW.length) l.onFrame(idx, buf, 4, (int) len - 4);
                }
                else if (type == RM_FILE && len >= 1) {
                    if ((buf[0] & 0xFF) == FT_ACK) {                 // 서버가 우리가 보낸 파일의 저장 결과를 알려 줌
                        synchronized (ackLock) { ack = len >= 2 && buf[1] != 0 ? 1 : 0; ackLock.notifyAll(); }
                    } else {
                        onServerFile(buf);                          // 서버가 보내는 파일 (BEGIN / DATA / END / ABORT)
                    }
                }
                // 그 밖의 종류는 쓰지 않으므로 버림
            }
        } catch (IOException e) {
            final String w = ioWhy;
            if (!closed) why = "연결이 끊어졌습니다 (" + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()) + ")";
            else if (w != null) why = w;
        }
        rxDrop();                               // 연결이 끊겨 끝나지 않은 파일은 버림
        final boolean user = byUser;
        shutdown();
        final Listener l = listener;
        if (!user && l != null) l.onClosed(why);
    }

    private void writeLoop() {
        try {
            while (!closed) {
                byte[] m = q.take();
                if (m.length == 0) break;
                out.write(m);
                if (q.isEmpty()) out.flush();
            }
        } catch (IOException e) {
            if (!closed) ioWhy = "서버로 보내지 못해 연결이 끊어졌습니다 (" + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()) + ")";
        } catch (InterruptedException ignored) {
        }
        shutdown();
    }

    // ---------------------------------------------------------------- 서버 -> 클라이언트 파일 수신
    private void rxDrop() {
        if (rxOut != null) {
            try { rxOut.close(); } catch (IOException ignored) { }
            rxOut = null;
            final FileSink k = fileSink;
            if (k != null) k.done(rxName, false, rxGot);
        }
        rxBad = true;
    }

    private void onServerFile(byte[] b) {
        final int sub = b[0] & 0xFF;
        if (sub == FT_BEGIN) {
            rxDrop();
            rxGot = 0;
            rxSize = 0;
            if (b.length < 10) return;
            rxSize = le64(b, 1);
            rxName = new String(b, 9, b.length - 9, StandardCharsets.UTF_8);
            final FileSink k = fileSink;
            if (k == null) return;
            try {
                rxOut = k.open(rxName, rxSize);
                rxBad = rxOut == null;
            } catch (IOException e) {
                rxOut = null;
                rxBad = true;
            }
        } else if (sub == FT_DATA) {
            if (rxBad || rxOut == null) return;
            try {
                rxOut.write(b, 1, b.length - 1);
                rxGot += b.length - 1;
            } catch (IOException e) {
                rxBad = true;
            }
        } else if (sub == FT_END) {
            boolean ok = !rxBad && rxOut != null && rxGot == rxSize;
            if (rxOut != null) {
                try { rxOut.close(); } catch (IOException e) { ok = false; }
                rxOut = null;
                final FileSink k = fileSink;
                if (k != null) k.done(rxName, ok, rxGot);
            }
            rxBad = true;
            post(RM_FILE, new byte[]{(byte) FT_ACK, (byte) (ok ? 1 : 0)});
        } else if (sub == FT_ABORT) {
            rxDrop();
        }
    }

    // ---------------------------------------------------------------- 클라이언트 -> 서버 파일 전송 / 명령
    /**
     * 파일 하나를 서버로 보냄 (블로킹, 백그라운드 스레드에서 한 번에 하나씩 호출): BEGIN -> DATA 조각들 -> END -> 서버 응답 대기.
     * 성공하면 null, 실패하면 사유 문장. size 는 in 에서 읽을 바이트 수와 같아야 함.
     */
    public String sendFile(String name, long size, InputStream in, Progress p) {
        final byte[] nb = name.getBytes(StandardCharsets.UTF_8);
        final byte[] pk = new byte[9 + nb.length];
        pk[0] = (byte) FT_BEGIN;
        put64(pk, 1, size);
        System.arraycopy(nb, 0, pk, 9, nb.length);
        synchronized (ackLock) { ack = -1; }
        if (closed) return "연결이 끊어짐";
        post(RM_FILE, pk);
        final byte[] buf = new byte[FILE_CHUNK];
        long sent = 0;
        String why = null;
        try {
            while (sent < size) {
                if (closed) { why = "연결이 끊어짐"; break; }
                if (p != null && !p.onProgress(sent, size)) { why = "사용자가 취소함"; break; }
                int want = (int) Math.min(buf.length, size - sent);
                int n = in.read(buf, 0, want);
                if (n <= 0) { why = "파일을 읽을 수 없음"; break; }
                while (q.size() > 8 && !closed) Thread.sleep(2);       // 네트워크보다 빨리 읽어 메모리에 쌓이지 않게
                final byte[] m = new byte[5 + 1 + n];
                m[0] = (byte) RM_FILE;
                put32(m, 1, 1 + n);
                m[5] = (byte) FT_DATA;
                System.arraycopy(buf, 0, m, 6, n);
                if (closed) { why = "연결이 끊어짐"; break; }
                q.offer(m);
                sent += n;
            }
        } catch (IOException e) {
            why = "파일을 읽을 수 없음";
        } catch (InterruptedException e) {
            why = "중단됨";
        }
        if (why != null) {
            if (!closed) post(RM_FILE, new byte[]{(byte) FT_ABORT});
            return why;
        }
        if (p != null) p.onProgress(size, size);
        post(RM_FILE, new byte[]{(byte) FT_END});
        final long end = System.currentTimeMillis() + ACK_WAIT_MS;
        synchronized (ackLock) {
            while (ack < 0 && !closed) {
                final long left = end - System.currentTimeMillis();
                if (left <= 0) return "서버 응답 없음";
                try { ackLock.wait(Math.min(left, 500)); } catch (InterruptedException e) { return "중단됨"; }
            }
            if (ack < 0) return "연결이 끊어짐";
            if (ack == 0) return "서버가 저장하지 못함 (디스크/권한 확인)";
        }
        return null;
    }

    /** 서버에 명령 전달 (CMD_GETLOGS / CMD_REBOOT). 옛 서버는 무시함 */
    public void command(int cmd) { post(RM_CMD, new byte[]{(byte) cmd}); }

    // ---------------------------------------------------------------- 입력 (어느 스레드에서든 호출 가능)
    private void post(int type, byte[] payload) {
        if (closed) return;
        q.offer(pack(type, payload, payload.length));
    }

    public void ev(int t, int a, int b, int m) {
        if (t == EV_MOVE && q.size() > 32) return;      // 네트워크가 밀리면 마우스 이동은 건너뜀
        byte[] p = new byte[16];
        put32(p, 0, t);
        put32(p, 4, a);
        put32(p, 8, b);
        put32(p, 12, m);
        post(RM_INPUT, p);
    }

    /** 모니터 mon 안의 위치 (0.0 ~ 1.0) 로 마우스 이동 */
    public void move(int mon, float nx, float ny) {
        ev(EV_MOVE, norm(nx), norm(ny), mon);
    }

    public void button(int flag) { ev(EV_BTN, flag, 0, 0); }

    public void wheel(int delta) { ev(EV_WHEEL, delta, 0, 0); }

    /** 키 이벤트: ext = 확장 키(방향키 등), scan = 스캔 코드 */
    public void key(int vk, boolean up, boolean ext, int scan) {
        ev(EV_KEY, vk, (up ? 1 : 0) | (ext ? 2 : 0), scan);
    }

    // ---------------------------------------------------------------- 바이트 도우미
    static int norm(float v) {
        int i = Math.round(v * 65535f);
        return i < 0 ? 0 : Math.min(i, 65535);
    }

    static byte[] pack(int type, byte[] payload, int len) {
        byte[] m = new byte[5 + len];
        m[0] = (byte) type;
        put32(m, 1, len);
        System.arraycopy(payload, 0, m, 5, len);
        return m;
    }

    static void put32(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
        b[o + 2] = (byte) (v >> 16);
        b[o + 3] = (byte) (v >> 24);
    }

    static void put64(byte[] b, int o, long v) {
        for (int i = 0; i < 8; i++) b[o + i] = (byte) (v >> (8 * i));
    }

    static long le64(byte[] b, int o) {
        long v = 0;
        for (int i = 7; i >= 0; i--) v = (v << 8) | (b[o + i] & 0xFFL);
        return v;
    }

    static long le32(byte[] b, int o) {
        return ((b[o] & 0xFFL) | (b[o + 1] & 0xFFL) << 8 | (b[o + 2] & 0xFFL) << 16 | (b[o + 3] & 0xFFL) << 24);
    }
}
