package com.garpsu.homemanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

/**
 * 서버 모니터 한 대의 화면을 보여 주고, 터치를 마우스로, 키보드 입력을 서버 키로 바꿔 보낸다.
 * 터치패드 방식: 한 손가락 끌기 = 커서 이동, 탭 = 왼쪽 클릭, 길게 눌러 끌기 = 드래그,
 *               두 손가락 탭 = 오른쪽 클릭, 두 손가락 위아래 끌기 = 휠, 두 손가락 벌리기/오므리기 = 확대/축소(두 손가락 이동 = 화면 옮기기).
 */
public class ScreenView extends View implements Session.Listener {
    private static final float GAIN = 1.5f;                 // 손가락 이동 -> 커서 이동 배율
    private static final int LONG_PRESS_MS = 450, TAP_MS = 300, WHEEL_STEP_DP = 24;
    private static final int[] EMPTY = new int[0];

    private final Session sess;
    private final float density;
    private final int slop;
    private volatile int mon = 0;
    private float nx = 0.5f, ny = 0.5f;                     // 커서 위치 (모니터 안의 0.0 ~ 1.0)
    private volatile Bitmap bmp;
    private final byte[][] lastBuf;                         // 모니터별 마지막 JPEG (보고 있는 모니터만 디코딩)
    private final int[] lastOff, lastLen;
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint curFill = new Paint(Paint.ANTI_ALIAS_FLAG), curLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF dst = new RectF();
    private final Path arrow = new Path();
    private Runnable doubleTapExit;                          // 전체화면일 때만 설정: 빠른 두 번 탭 = 전체화면 해제
    private long lastTapT;
    private float lastTapX, lastTapY;
    private float zoom = 1f, panX, panY;                    // 확대 배율(1 = 화면에 맞춤)과 화면 이동량(px)
    private static final float MAX_ZOOM = 6f;

    // 터치 상태
    private float lastX, lastY, downX, downY, twoY, twoStartY, wheelAcc;
    private long downT, twoT;
    private boolean moved, multi, twoMoved, dragging, pinching;
    private float pinchD, pinchX, pinchY;
    private final Runnable longPress = new Runnable() {
        @Override public void run() {
            if (!moved && !multi) {
                dragging = true;
                sess.button(Session.BTN_LDOWN);
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            }
        }
    };

    // 키보드 상태
    public volatile boolean ctrlOn, altOn;                  // 도구 줄의 Ctrl / Alt (다음 키 한 번에만 적용)
    private boolean ctrlSent, altSent, shiftHeld, wrapShift;
    private int[] sentComp = EMPTY;                         // 지금 조합 중인 글자가 서버로 보낸 키들
    private Runnable modsChanged;

    public ScreenView(Context c, Session s) {
        super(c);
        sess = s;
        density = c.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        lastBuf = new byte[s.monW.length][];
        lastOff = new int[s.monW.length];
        lastLen = new int[s.monW.length];
        setFocusable(true);
        setFocusableInTouchMode(true);
        setBackgroundColor(Color.BLACK);
        textPaint.setColor(Color.LTGRAY);
        textPaint.setTextSize(16 * density);
        textPaint.setTextAlign(Paint.Align.CENTER);
        curFill.setColor(Color.WHITE);
        curLine.setColor(Color.BLACK);
        curLine.setStyle(Paint.Style.STROKE);
        curLine.setStrokeWidth(2 * density);
        arrow.moveTo(0, 0);
        arrow.lineTo(0, 22 * density);
        arrow.lineTo(6 * density, 17 * density);
        arrow.lineTo(11 * density, 27 * density);
        arrow.lineTo(15 * density, 25 * density);
        arrow.lineTo(10 * density, 16 * density);
        arrow.lineTo(17 * density, 16 * density);
        arrow.close();
    }

    public void setModsChangedCallback(Runnable r) { modsChanged = r; }

    /** r != null 이면 빠른 두 번 탭을 r 로 처리하고 서버에는 두 번째 클릭을 보내지 않음. null 이면 해제 */
    public void setDoubleTapExit(Runnable r) { doubleTapExit = r; lastTapT = 0; }

    public int monitorCount() { return sess.monW.length; }

    public int monitor() { return mon; }

    /** 다음 모니터로 전환 (서버 마우스도 그 모니터로 옮김) */
    public int nextMonitor() {
        mon = (mon + 1) % sess.monW.length;
        bmp = decode(mon);
        sess.move(mon, nx, ny);
        invalidate();
        return mon;
    }

    /** 처음 보여질 때 서버 마우스 위치를 화면의 커서와 맞춤 */
    public void syncCursor() { sess.move(mon, nx, ny); }

    // ---------------------------------------------------------------- 화면 받기 (Session.Listener, 읽기 스레드)
    @Override public void onFrame(int m, byte[] buf, int off, int len) {
        synchronized (this) { lastBuf[m] = buf; lastOff[m] = off; lastLen[m] = len; }
        if (m == mon) {
            Bitmap b = decode(m);
            if (b != null) { bmp = b; postInvalidate(); }
        }
    }

    @Override public void onClosed(String why) { }          // RemoteActivity 가 따로 처리

    private Bitmap decode(int m) {
        byte[] b;
        int o, l;
        synchronized (this) { b = lastBuf[m]; o = lastOff[m]; l = lastLen[m]; }
        return b == null ? null : BitmapFactory.decodeByteArray(b, o, l);
    }

    /** 확대 배율과 이동량으로 화면 그림이 놓일 사각형(dst)을 계산 (화면 밖으로 너무 벗어나지 않게 보정) */
    private void computeDst() {
        final Bitmap b = bmp;
        final int w = getWidth(), h = getHeight();
        if (b == null || w == 0 || h == 0) { dst.setEmpty(); return; }
        final float s = Math.min((float) w / b.getWidth(), (float) h / b.getHeight()) * zoom;
        final float dw = b.getWidth() * s, dh = b.getHeight() * s;
        final float mx = Math.max(0f, (dw - w) / 2f), my = Math.max(0f, (dh - h) / 2f);
        panX = Math.max(-mx, Math.min(mx, panX));
        panY = Math.max(-my, Math.min(my, panY));
        dst.set((w - dw) / 2f + panX, (h - dh) / 2f + panY, (w + dw) / 2f + panX, (h + dh) / 2f + panY);
    }

    /** 확대/축소 화면을 처음 상태(화면에 맞춤)로 되돌림 */
    public void resetZoom() { zoom = 1f; panX = panY = 0f; computeDst(); invalidate(); }

    /** (fx, fy) 지점이 제자리에 있도록 k 배 확대/축소 */
    private void zoomBy(float k, float fx, float fy) {
        computeDst();
        if (dst.isEmpty()) return;
        final float nz = Math.max(1f, Math.min(MAX_ZOOM, zoom * k));
        k = nz / zoom;
        if (k == 1f) return;
        final float w = getWidth(), h = getHeight();
        final float nw = dst.width() * k, nh = dst.height() * k;
        final float nl = fx - (fx - dst.left) * k, nt = fy - (fy - dst.top) * k;
        zoom = nz;
        panX = nl - (w - nw) / 2f;
        panY = nt - (h - nh) / 2f;
        computeDst();
    }

    /** 커서가 화면 밖으로 나가지 않도록 확대된 화면을 옮김 */
    private void followCursor() {
        final float m = 24 * density;
        final float cx = dst.left + nx * dst.width(), cy = dst.top + ny * dst.height();
        if (cx < m) panX += m - cx; else if (cx > getWidth() - m) panX -= cx - (getWidth() - m);
        if (cy < m) panY += m - cy; else if (cy > getHeight() - m) panY -= cy - (getHeight() - m);
        computeDst();
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(Color.BLACK);
        final Bitmap b = bmp;
        final int w = getWidth(), h = getHeight();
        if (b == null) {
            c.drawText("화면 수신 중...", w / 2f, h / 2f, textPaint);
            dst.setEmpty();
            return;
        }
        computeDst();
        final float dw = dst.width(), dh = dst.height();
        c.drawBitmap(b, null, dst, bmpPaint);
        c.save();
        c.translate(dst.left + nx * dw, dst.top + ny * dh);
        c.drawPath(arrow, curFill);
        c.drawPath(arrow, curLine);
        c.restore();
    }

    // ---------------------------------------------------------------- 터치 -> 마우스
    private void moveBy(float dx, float dy) {
        if (dst.isEmpty()) return;
        nx = Math.max(0f, Math.min(1f, nx + dx * GAIN / dst.width()));
        ny = Math.max(0f, Math.min(1f, ny + dy * GAIN / dst.height()));
        sess.move(mon, nx, ny);
        if (zoom > 1f) followCursor();
        invalidate();
    }

    private void click(int down, int up) {
        sess.move(mon, nx, ny);
        sess.button(down);
        sess.button(up);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = downX = e.getX();
                lastY = downY = e.getY();
                downT = e.getEventTime();
                moved = multi = twoMoved = dragging = pinching = false;
                wheelAcc = 0;
                postDelayed(longPress, LONG_PRESS_MS);
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                removeCallbacks(longPress);
                if (e.getPointerCount() == 2 && !dragging && !multi) {
                    multi = true;
                    twoMoved = false;
                    twoT = e.getEventTime();
                    twoY = twoStartY = (e.getY(0) + e.getY(1)) / 2f;
                    wheelAcc = 0;
                    pinching = false;
                    pinchD = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                    pinchX = (e.getX(0) + e.getX(1)) / 2f;
                    pinchY = twoY;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (multi) {
                    if (e.getPointerCount() >= 2) {
                        final float y = (e.getY(0) + e.getY(1)) / 2f;
                        final float mxp = (e.getX(0) + e.getX(1)) / 2f;
                        final float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                        if (!pinching && Math.abs(d - pinchD) > slop * 2) { pinching = true; twoMoved = true; }
                        if (pinching) {                                 // 확대/축소 + 화면 옮기기
                            if (pinchD > 0) zoomBy(d / pinchD, mxp, y);
                            panX += mxp - pinchX;
                            panY += y - pinchY;
                            computeDst();
                            pinchD = d;
                            pinchX = mxp;
                            pinchY = y;
                            twoY = y;
                            invalidate();
                            return true;
                        }
                        wheelAcc += y - twoY;
                        twoY = y;
                        if (Math.abs(y - twoStartY) > slop) twoMoved = true;
                        final float step = WHEEL_STEP_DP * density;
                        if (twoMoved) {
                            while (wheelAcc >= step) { sess.wheel(120); wheelAcc -= step; }       // 손가락을 아래로 = 위로 스크롤
                            while (wheelAcc <= -step) { sess.wheel(-120); wheelAcc += step; }
                        }
                    }
                } else {
                    final float x = e.getX(), y = e.getY();
                    if (!moved && Math.hypot(x - downX, y - downY) > slop) {
                        moved = true;
                        removeCallbacks(longPress);
                    }
                    if (moved || dragging) moveBy(x - lastX, y - lastY);
                    lastX = x;
                    lastY = y;
                }
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                if (multi && e.getPointerCount() == 2 && !twoMoved && !pinching && e.getEventTime() - twoT < TAP_MS) {
                    click(Session.BTN_RDOWN, Session.BTN_RUP);          // 두 손가락 탭 = 오른쪽 클릭
                    twoMoved = true;                                    // 한 번만
                }
                return true;
            case MotionEvent.ACTION_UP:
                removeCallbacks(longPress);
                if (dragging) sess.button(Session.BTN_LUP);
                else if (!multi && !moved && e.getEventTime() - downT < TAP_MS) {
                    final Runnable r = doubleTapExit;
                    final long now = e.getEventTime();
                    if (r != null && lastTapT != 0 && now - lastTapT < 400 && Math.hypot(e.getX() - lastTapX, e.getY() - lastTapY) < 60 * density) {
                        lastTapT = 0;
                        r.run();                                        // 전체화면 해제 (두 번째 클릭은 서버로 보내지 않음)
                    } else {
                        lastTapT = now;
                        lastTapX = e.getX();
                        lastTapY = e.getY();
                        click(Session.BTN_LDOWN, Session.BTN_LUP);
                    }
                }
                dragging = multi = pinching = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPress);
                if (dragging) sess.button(Session.BTN_LUP);
                dragging = multi = pinching = false;
                return true;
            default:
                return true;
        }
    }

    // ---------------------------------------------------------------- 키보드 -> 서버 키
    private void k(int vk, boolean up) { sess.key(vk, up, KeyMap.isExt(vk), KeyMap.scan(vk)); }

    private void modsDown() {
        if (ctrlOn && !ctrlSent) { k(KeyMap.VK_CONTROL, false); ctrlSent = true; }
        if (altOn && !altSent) { k(KeyMap.VK_MENU, false); altSent = true; }
    }

    private void modsUp() {
        boolean ch = false;
        if (ctrlSent) { k(KeyMap.VK_CONTROL, true); ctrlSent = ctrlOn = false; ch = true; }
        if (altSent) { k(KeyMap.VK_MENU, true); altSent = altOn = false; ch = true; }
        if (ch && modsChanged != null) post(modsChanged);
    }

    /** 키 하나를 눌렀다 뗌 (shift = Shift 와 함께). Ctrl / Alt 버튼이 켜져 있으면 함께 눌렀다 뗌 */
    private void tap(int vk, boolean shift) {
        modsDown();
        if (shift) k(KeyMap.VK_SHIFT, false);
        k(vk, false);
        k(vk, true);
        if (shift) k(KeyMap.VK_SHIFT, true);
        modsUp();
    }

    private void tapToken(int t) { tap(t & 0xFF, (t & KeyMap.SHIFT) != 0); }

    /** 도구 줄 버튼용 (방향키, Esc, Tab, 한/영 ...) */
    public void tapKey(int vk) {
        sentComp = EMPTY;
        tap(vk, false);
    }

    private void typeText(CharSequence s) {
        for (int t : KeyMap.tokens(s)) tapToken(t);
    }

    /** 조합 중인 글자를 s 로 바꿈: 앞부분이 같으면 뒤만 보내고, 달라진 부분은 BackSpace 로 지우고 다시 침 (서버 IME 가 같은 조합을 따라감) */
    private void setComposing(CharSequence s) {
        final int[] nt = KeyMap.tokens(s);
        int p = 0;
        while (p < sentComp.length && p < nt.length && sentComp[p] == nt[p]) p++;
        for (int i = p; i < sentComp.length; i++) tap(KeyMap.VK_BACK, false);
        for (int i = p; i < nt.length; i++) tapToken(nt[i]);
        sentComp = nt;
    }

    private void commit(CharSequence s) {
        if (sentComp.length > 0) setComposing(s); else typeText(s);
        sentComp = EMPTY;
    }

    private static int vkOf(int kc) {
        if (kc >= KeyEvent.KEYCODE_A && kc <= KeyEvent.KEYCODE_Z) return 0x41 + (kc - KeyEvent.KEYCODE_A);
        if (kc >= KeyEvent.KEYCODE_0 && kc <= KeyEvent.KEYCODE_9) return 0x30 + (kc - KeyEvent.KEYCODE_0);
        if (kc >= KeyEvent.KEYCODE_F1 && kc <= KeyEvent.KEYCODE_F12) return KeyMap.VK_F1 + (kc - KeyEvent.KEYCODE_F1);
        switch (kc) {
            case KeyEvent.KEYCODE_SPACE: return KeyMap.VK_SPACE;
            case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_NUMPAD_ENTER: return KeyMap.VK_RETURN;
            case KeyEvent.KEYCODE_TAB: return KeyMap.VK_TAB;
            case KeyEvent.KEYCODE_DEL: return KeyMap.VK_BACK;
            case KeyEvent.KEYCODE_FORWARD_DEL: return KeyMap.VK_DELETE;
            case KeyEvent.KEYCODE_ESCAPE: return KeyMap.VK_ESCAPE;
            case KeyEvent.KEYCODE_DPAD_LEFT: return KeyMap.VK_LEFT;
            case KeyEvent.KEYCODE_DPAD_UP: return KeyMap.VK_UP;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return KeyMap.VK_RIGHT;
            case KeyEvent.KEYCODE_DPAD_DOWN: return KeyMap.VK_DOWN;
            case KeyEvent.KEYCODE_MOVE_HOME: return KeyMap.VK_HOME;
            case KeyEvent.KEYCODE_MOVE_END: return KeyMap.VK_END;
            case KeyEvent.KEYCODE_PAGE_UP: return KeyMap.VK_PRIOR;
            case KeyEvent.KEYCODE_PAGE_DOWN: return KeyMap.VK_NEXT;
            case KeyEvent.KEYCODE_INSERT: return KeyMap.VK_INSERT;
            case KeyEvent.KEYCODE_CAPS_LOCK: return KeyMap.VK_CAPITAL;
            case KeyEvent.KEYCODE_SHIFT_LEFT: case KeyEvent.KEYCODE_SHIFT_RIGHT: return KeyMap.VK_SHIFT;
            case KeyEvent.KEYCODE_CTRL_LEFT: case KeyEvent.KEYCODE_CTRL_RIGHT: return KeyMap.VK_CONTROL;
            case KeyEvent.KEYCODE_ALT_LEFT: case KeyEvent.KEYCODE_ALT_RIGHT: return KeyMap.VK_MENU;
            case KeyEvent.KEYCODE_META_LEFT: case KeyEvent.KEYCODE_META_RIGHT: return KeyMap.VK_LWIN;
            case KeyEvent.KEYCODE_MINUS: return 0xBD;
            case KeyEvent.KEYCODE_EQUALS: return 0xBB;
            case KeyEvent.KEYCODE_LEFT_BRACKET: return 0xDB;
            case KeyEvent.KEYCODE_RIGHT_BRACKET: return 0xDD;
            case KeyEvent.KEYCODE_BACKSLASH: return 0xDC;
            case KeyEvent.KEYCODE_SEMICOLON: return 0xBA;
            case KeyEvent.KEYCODE_APOSTROPHE: return 0xDE;
            case KeyEvent.KEYCODE_COMMA: return 0xBC;
            case KeyEvent.KEYCODE_PERIOD: return 0xBE;
            case KeyEvent.KEYCODE_SLASH: return 0xBF;
            case KeyEvent.KEYCODE_GRAVE: return 0xC0;
            default: return -1;                                 // 뒤로 가기 / 볼륨 등은 앱이 처리
        }
    }

    /** 키 이벤트 하나 처리 (하드웨어 키보드, 소프트 키보드의 sendKeyEvent). 처리했으면 true */
    private boolean handleKeyEvent(KeyEvent e) {
        final int act = e.getAction();
        if (act == KeyEvent.ACTION_MULTIPLE && e.getKeyCode() == KeyEvent.KEYCODE_UNKNOWN) {
            final String s = e.getCharacters();
            if (s != null) commit(s);
            return true;
        }
        final int vk = vkOf(e.getKeyCode());
        if (vk < 0) return false;
        sentComp = EMPTY;
        final boolean isMod = vk == KeyMap.VK_SHIFT || vk == KeyMap.VK_CONTROL || vk == KeyMap.VK_MENU;
        if (act == KeyEvent.ACTION_DOWN) {
            if (vk == KeyMap.VK_SHIFT) shiftHeld = true;
            if (!isMod && e.getRepeatCount() == 0) {
                modsDown();
                if (KeyMap.isPrintable(vk) && e.isShiftPressed() && !shiftHeld) { k(KeyMap.VK_SHIFT, false); wrapShift = true; }
            }
            k(vk, false);
        } else if (act == KeyEvent.ACTION_UP) {
            k(vk, true);
            if (vk == KeyMap.VK_SHIFT) shiftHeld = false;
            if (!isMod) {
                if (wrapShift) { k(KeyMap.VK_SHIFT, true); wrapShift = false; }
                modsUp();
            }
        }
        return true;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent e) { return handleKeyEvent(e) || super.onKeyDown(keyCode, e); }

    @Override public boolean onKeyUp(int keyCode, KeyEvent e) { return handleKeyEvent(e) || super.onKeyUp(keyCode, e); }

    @Override public boolean onCheckIsTextEditor() { return true; }

    @Override public InputConnection onCreateInputConnection(EditorInfo out) {
        out.inputType = android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;
        out.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_FLAG_NO_FULLSCREEN | EditorInfo.IME_ACTION_NONE;
        return new Ic(this);
    }

    /** 소프트 키보드 입력 연결: 글자는 서버 키로 풀어서 보내고, 키보드가 보는 글 내용은 항상 비어 있다고 알림 */
    private class Ic extends BaseInputConnection {
        Ic(View v) { super(v, false); }

        @Override public boolean commitText(CharSequence t, int pos) { commit(t); return true; }

        @Override public boolean setComposingText(CharSequence t, int pos) { setComposing(t); return true; }

        @Override public boolean finishComposingText() { sentComp = EMPTY; return true; }

        @Override public boolean setComposingRegion(int s, int e) { return true; }

        @Override public boolean deleteSurroundingText(int before, int after) {
            sentComp = EMPTY;
            for (int i = 0; i < before; i++) tap(KeyMap.VK_BACK, false);
            for (int i = 0; i < after; i++) tap(KeyMap.VK_DELETE, false);
            return true;
        }

        @Override public boolean sendKeyEvent(KeyEvent e) { return handleKeyEvent(e); }

        @Override public boolean performEditorAction(int action) { tapKey(KeyMap.VK_RETURN); return true; }

        @Override public CharSequence getTextBeforeCursor(int n, int flags) { return ""; }

        @Override public CharSequence getTextAfterCursor(int n, int flags) { return ""; }

        @Override public CharSequence getSelectedText(int flags) { return ""; }
    }
}
