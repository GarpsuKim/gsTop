package com.garpsu.homemanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** 원격 화면: 위쪽 도구 줄(키보드, 한/영, Esc, Tab, Ctrl, Alt, 방향키, 모니터 전환, 종료) + 서버 화면 */
public class RemoteActivity extends Activity {
    private Session sess;
    private ScreenView view;
    private Button btnCtrl, btnAlt, btnMon;
    private static final int REQ_PICK = 7;
    private boolean kbVisible, fullscreen;
    private volatile boolean cancelUpload;
    private Button btnUpload;
    private View panel;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sess = Session.current;
        if (sess == null || sess.isClosed()) {
            Toast.makeText(this, "서버 연결이 없어 접속 화면으로 돌아갑니다. (앱이 다시 시작되었을 수 있습니다)", Toast.LENGTH_LONG).show();
            KeepAliveService.stop(this);
            finish();
            return;
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        view = new ScreenView(this, sess);
        view.setModsChangedCallback(this::updateModButtons);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.addView(mk("키보드", v -> toggleKeyboard()));
        bar.addView(mk("한/영", v -> view.tapKey(KeyMap.VK_HANGUL)));
        bar.addView(mk("Esc", v -> view.tapKey(KeyMap.VK_ESCAPE)));
        bar.addView(mk("Tab", v -> view.tapKey(KeyMap.VK_TAB)));
        btnCtrl = mk("Ctrl", v -> { view.ctrlOn = !view.ctrlOn; updateModButtons(); });
        bar.addView(btnCtrl);
        btnAlt = mk("Alt", v -> { view.altOn = !view.altOn; updateModButtons(); });
        bar.addView(btnAlt);
        bar.addView(mk("←", v -> view.tapKey(KeyMap.VK_LEFT)));
        bar.addView(mk("↑", v -> view.tapKey(KeyMap.VK_UP)));
        bar.addView(mk("↓", v -> view.tapKey(KeyMap.VK_DOWN)));
        bar.addView(mk("→", v -> view.tapKey(KeyMap.VK_RIGHT)));
        bar.addView(mk("Del", v -> view.tapKey(KeyMap.VK_DELETE)));
        bar.addView(mk("맞춤", v -> view.resetZoom()));
        btnMon = mk("", v -> { view.nextMonitor(); updateMonButton(); });
        bar.addView(btnMon);
        btnUpload = mk("파일 업로드", v -> onUploadButton());
        btnUpload.setBackgroundColor(0xFF0066CC);               // PC 쪽과 같은 파란색
        btnUpload.setTextColor(0xFFFFFFFF);
        bar.addView(btnUpload);
        bar.addView(mk("로그 다운로드", v -> {
            sess.command(Session.CMD_GETLOGS);
            Toast.makeText(this, "서버에 로그 파일 전송을 요청했습니다.\n받은 파일은 이 폰의 Download/HomeManager 폴더에 저장됩니다.", Toast.LENGTH_LONG).show();
        }));
        bar.addView(mk("서버 reboot", v -> confirmReboot()));
        bar.addView(mk("전체화면", v -> setFullscreen(true)));
        bar.addView(mk("종료", v -> confirmExit()));
        updateMonButton();

        ScrollView scroll = new ScrollView(this);               // 오른쪽 세로 메뉴 (버튼이 많으면 위아래로 스크롤)
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(bar);
        panel = scroll;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(view, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        sess.setFileSink(new Receiver(this));                   // 서버가 보내는 파일(로그 등)을 폰에 저장
        sess.start(new Session.Listener() {
            @Override public void onFrame(int mon, byte[] buf, int off, int len) { view.onFrame(mon, buf, off, len); }

            @Override public void onClosed(final String why) {
                runOnUiThread(() -> {
                    Toast.makeText(RemoteActivity.this, why, Toast.LENGTH_LONG).show();
                    KeepAliveService.stop(RemoteActivity.this);
                    finish();
                });
            }
        });
        view.syncCursor();
    }

    private Button mk(String text, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(text);
        x.setAllCaps(false);
        x.setMinWidth(0);
        x.setMinimumWidth(0);
        final int h = (int) (64 * getResources().getDisplayMetrics().density);   // 높이를 넉넉하게 (많으면 스크롤)
        x.setMinHeight(h);
        x.setMinimumHeight(h);
        x.setTextSize(15);
        x.setPadding(20, 12, 20, 12);
        x.setFocusable(false);                  // 버튼을 눌러도 화면 뷰가 포커스(키보드 연결)를 유지하게
        x.setOnClickListener(l);
        x.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return x;
    }

    private void updateModButtons() {
        btnCtrl.setText(view.ctrlOn ? "● Ctrl" : "Ctrl");
        btnAlt.setText(view.altOn ? "● Alt" : "Alt");
    }

    private void updateMonButton() {
        btnMon.setText("모니터 " + (view.monitor() + 1) + "/" + view.monitorCount());
        btnMon.setEnabled(view.monitorCount() > 1);
    }

    private void toggleKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (kbVisible) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } else {
            view.requestFocus();
            imm.showSoftInput(view, InputMethodManager.SHOW_FORCED);
        }
        kbVisible = !kbVisible;
    }

    private void confirmReboot() {
        new AlertDialog.Builder(this)
                .setMessage("서버 PC 를 지금 바로 재부팅합니다.\n계속하시겠습니까?")
                .setPositiveButton("Yes", (d, w) -> sess.command(Session.CMD_REBOOT))
                .setNegativeButton("No", null)
                .show();
    }

    // ---------------------------------------------------------------- 파일 업로드 (폰 -> 서버)
    private void onUploadButton() {
        if (Uploader.busy.get()) { cancelUpload = true; return; }            // 전송 중에는 이 버튼이 [취소]
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_PICK);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        final List<Uri> uris = new ArrayList<>();
        final ClipData cd = data.getClipData();
        if (cd != null) for (int k = 0; k < cd.getItemCount(); k++) uris.add(cd.getItemAt(k).getUri());
        else if (data.getData() != null) uris.add(data.getData());
        if (uris.isEmpty()) return;
        cancelUpload = false;
        if (!Uploader.start(this, sess, uris, new Uploader.Callback() {
            @Override public boolean onProgress(int no, int total, long sent, long size) {
                setUploadText("취소 (" + no + "/" + total + ", " + (size > 0 ? sent * 100 / size : 100) + "%)");
                return !cancelUpload;
            }

            @Override public void onFinished(final String summary) {
                runOnUiThread(() -> {
                    btnUpload.setText("파일 업로드");
                    if (!isFinishing()) new AlertDialog.Builder(RemoteActivity.this).setMessage(summary).setPositiveButton("확인", null).show();
                });
            }
        })) Toast.makeText(this, "다른 업로드가 진행 중입니다.", Toast.LENGTH_LONG).show();
    }

    private void setUploadText(final String s) { runOnUiThread(() -> btnUpload.setText(s)); }

    private void confirmExit() {
        new AlertDialog.Builder(this)
                .setMessage("서버 연결을 종료합니까?")
                .setPositiveButton("Yes", (d, w) -> finish())
                .setNegativeButton("No", null)
                .show();
    }

    /** 전체화면: 상태 표시줄/탐색 막대와 오른쪽 메뉴를 모두 숨김. 뒤로 가기를 누르면 원래대로 */
    private void setFullscreen(boolean on) {
        fullscreen = on;
        panel.setVisibility(on ? View.GONE : View.VISIBLE);
        view.setDoubleTapExit(on ? () -> setFullscreen(false) : null);
        applySystemUi();
    }

    @SuppressWarnings("deprecation")
    private void applySystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(fullscreen
                ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                  | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                : View.SYSTEM_UI_FLAG_VISIBLE);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && fullscreen) applySystemUi();
    }

    @Override public void onBackPressed() {
        if (fullscreen) setFullscreen(false); else confirmExit();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (isFinishing() && sess != null) {
            sess.close();
            if (Session.current == sess) Session.current = null;
            KeepAliveService.stop(this);
        }
    }
}
